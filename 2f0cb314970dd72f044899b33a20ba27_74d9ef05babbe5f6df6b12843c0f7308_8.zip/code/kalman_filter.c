/**
 ******************************************************************************
 * @file    kalman filter.c
 * @author  Wang Hongxi
 * @version V1.2.2
 * @date    2022/1/8
 * @brief   C implementation of kalman filter
 ******************************************************************************
 * @attention
 * �ÿ������˲��������ڴ���������Ƶ�ʲ�ͬ������£���̬��������H R��K��ά������ֵ��
 * This implementation of kalman filter can dynamically adjust dimension and
 * value of matrix H R and K according to the measurement validity under any
 * circumstance that the sampling rate of component sensors are different.
 *
 * ��˾���H��R�ĳ�ʼ���������P A��Q������ͬ������ģ��ڳ�ʼ����������zʱ��Ҫ����д
 * �봫������������Ӧ��״̬���������ķ�ʽ�������������
 * Therefore, the initialization of matrix P, F, and Q is sometimes different
 * from that of matrices H R. when initialization. Additionally, the corresponding
 * state and the method of the measurement should be provided when initializing
 * measurement vector z. For more details, please see the example.
 *
 * ������Ҫ��̬������������z���ɼ򵥽��ṹ���е�Use_Auto_Adjustment��ʼ��Ϊ0�������
 * ʼ������P�����ó��淽ʽ��ʼ��z H R���ɡ�
 * If automatic adjustment is not required, assign zero to the UseAutoAdjustment
 * and initialize z H R in the normal way as matrix P.
 *
 * Ҫ����������z���������u�ڴ������ص������и��¡�����0��ζ��������Ч�������ϴο�����
 * �˲����º��޴��������ݸ��¡������������z���������u���ڿ������˲����¹����б�����
 * MeasuredVector and ControlVector are required to be updated in the sensor
 * callback function. Integer 0 in measurement vector z indicates the invalidity
 * of current measurement, so MeasuredVector and ControlVector will be reset
 * (to 0) during each update.
 *
 * ���⣬����P�����������˲�������������Ӧ״̬�Ļ����仯���Ӷ������˲�����ƫ����㷨
 * ͨ�����ƾ���P��Сֵ�ķ���������Ч�����˲����Ĺ�������������������̡�
 * Additionally, the excessive convergence of matrix P will make filter incapable
 * of adopting the slowly changing state. This implementation can effectively
 * suppress filter excessive convergence through boundary limiting for matrix P.
 * For more details, please see the example.
 *
 * @example:
 * x =
 *   |   height   |
 *   |  velocity  |
 *   |acceleration|
 *
 * KalmanFilter_t Height_KF;
 *
 * void INS_Task_Init(void)
 * {
 *     static float P_Init[9] =
 *     {
 *         10, 0, 0,
 *         0, 30, 0,
 *         0, 0, 10,
 *     };
 *     static float F_Init[9] =
 *     {
 *         1, dt, 0.5*dt*dt,
 *         0, 1, dt,
 *         0, 0, 1,
 *     };
 *     static float Q_Init[9] =
 *     {
 *         0.25*dt*dt*dt*dt, 0.5*dt*dt*dt, 0.5*dt*dt,
 *         0.5*dt*dt*dt,        dt*dt,         dt,
 *         0.5*dt*dt,              dt,         1,
 *     };
 *
 *     // ������С����
 *     static float state_min_variance[3] = {0.03, 0.005, 0.1};
 *
 *     // �����Զ�����
 *     Height_KF.UseAutoAdjustment = 1;
 *
 *     // ��ѹ��ø߶� GPS��ø߶� ���ٶȼƲ��z���˶����ٶ�
 *     static uint8_t measurement_reference[3] = {1, 1, 3}
 *
 *     static float measurement_degree[3] = {1, 1, 1}
 *     // ����measurement_reference��measurement_degree����H�������£��ڵ�ǰ����ȫ������������Ч����£�
 *       |1   0   0|
 *       |1   0   0|
 *       |0   0   1|
 *
 *     static float mat_R_diagonal_elements = {30, 25, 35}
 *     //����mat_R_diagonal_elements����R�������£��ڵ�ǰ����ȫ������������Ч����£�
 *       |30   0   0|
 *       | 0  25   0|
 *       | 0   0  35|
 *
 *     Kalman_Filter_Init(&Height_KF, 3, 0, 3);
 *
 *     // ���þ���ֵ
 *     memcpy(Height_KF.P_data, P_Init, sizeof(P_Init));
 *     memcpy(Height_KF.F_data, F_Init, sizeof(F_Init));
 *     memcpy(Height_KF.Q_data, Q_Init, sizeof(Q_Init));
 *     memcpy(Height_KF.MeasurementMap, measurement_reference, sizeof(measurement_reference));
 *     memcpy(Height_KF.MeasurementDegree, measurement_degree, sizeof(measurement_degree));
 *     memcpy(Height_KF.MatR_DiagonalElements, mat_R_diagonal_elements, sizeof(mat_R_diagonal_elements));
 *     memcpy(Height_KF.StateMinVariance, state_min_variance, sizeof(state_min_variance));
 * }
 *
 * void INS_Task(void const *pvParameters)
 * {
 *     // ѭ������
 *     Kalman_Filter_Update(&Height_KF);
 *     vTaskDelay(ts);
 * }
 *
 * // �������ݸ���Ӧ����������ʽ ����MeasuredVector��ֵ
 * void Barometer_Read_Over(void)
 * {
 *     ......
 *     INS_KF.MeasuredVector[0] = baro_height;
 * }
 * void GPS_Read_Over(void)
 * {
 *     ......
 *     INS_KF.MeasuredVector[1] = GPS_height;
 * }
 * void Acc_Data_Process(void)
 * {
 *     ......
 *     INS_KF.MeasuredVector[2] = acc.z;
 * }
 ******************************************************************************
 */

#include "kalman_filter.h"
//#include "FreeRTOS.h"
//#include "task.h"
#include "stdlib.h"

uint16_t sizeof_float, sizeof_double;

static inline  void H_K_R_Adjustment(KalmanFilter_t *kf);


#define user_malloc malloc

//================================================================================================================================
//ԭ����������malloc�����ڴ���䣬����Ϊ�����������ʹ��ȫ�ֱ������������㵽������Ƭ��ϵͳ�ϡ� �������ܳ�ʹ��
#define Kalman_xhatSize 6
#define Kalman_uSize 0
#define Kalman_zSize 3

// measurement flags
uint8_t MeasurementMap_Temp[Kalman_zSize]={0};
float MeasurementDegree_Temp[Kalman_zSize]={0};
float MatR_DiagonalElements_Temp[Kalman_zSize]={0};
float StateMinVariance_Temp[Kalman_xhatSize]={0};
uint8_t temp_Temp[Kalman_zSize]={0};

// filter data
float FilteredValue_Temp[Kalman_xhatSize]={0};
float MeasuredVector_Temp[Kalman_zSize]={0};

// xhat x(k|k)
float xhat_data_Temp[Kalman_xhatSize]={0};

// xhatminus x(k|k-1)
float xhatminus_data_Temp[Kalman_xhatSize]={0};

// measurement vector z
float z_data_Temp[Kalman_zSize]={0};

// covariance matrix P(k|k)
float P_data_Temp[Kalman_xhatSize*Kalman_xhatSize]={0};

// create covariance matrix P(k|k-1)
float Pminus_data_Temp[Kalman_xhatSize*Kalman_xhatSize]={0};

// state transition matrix F FT
float FT_data_Temp[Kalman_xhatSize*Kalman_xhatSize]={0};
float F_data_Temp[Kalman_xhatSize*Kalman_xhatSize]={0};

// measurement matrix H
float HT_data_Temp[Kalman_xhatSize*Kalman_zSize]={0};
float H_data_Temp[Kalman_xhatSize*Kalman_zSize]={0};

// process noise covariance matrix Q
float Q_data_Temp[Kalman_xhatSize*Kalman_xhatSize]={0};

// measurement noise covariance matrix R
float R_data_Temp[Kalman_zSize*Kalman_zSize]={0};

// kalman gain K
float K_data_Temp[Kalman_zSize*Kalman_xhatSize]={0};

float S_data_Temp[Kalman_xhatSize*Kalman_xhatSize]={0};
float temp_matrix_data_Temp[Kalman_xhatSize*Kalman_xhatSize]={0};
float temp_matrix_data1_Temp[Kalman_xhatSize*Kalman_xhatSize]={0};
float temp_vector_data_Temp[Kalman_xhatSize]={0};
float temp_vector_data1_Temp[Kalman_xhatSize]={0};
/**
 * @brief ��ʼ������ά����Ϣ��Ϊ�������ռ�
 *
 * @param kf kf���Ͷ���
 * @param xhatSize ״̬����ά��
 * @param uSize ���Ʊ���ά��
 * @param zSize �۲���ά��
 */
//Kalman_Filter_Init    &QEKF_INS.IMU_QuaternionEKF, 6,           0,                  3);
void Kalman_Filter_Init(KalmanFilter_t *kf, uint8_t xhatSize, uint8_t uSize, uint8_t zSize)
{

    sizeof_float = sizeof(float);
    sizeof_double = sizeof(double);

    kf->xhatSize = Kalman_xhatSize;
    kf->uSize = Kalman_uSize;
    kf->zSize = Kalman_zSize;

    kf->MeasurementValidNum = 0;

    // measurement flags
    // kf->MeasurementMap = (uint8_t *)user_malloc(sizeof(uint8_t) * zSize);
    // memset(kf->MeasurementMap, 0, sizeof(uint8_t) * zSize);
    kf->MeasurementMap=MeasurementMap_Temp;
    // kf->MeasurementDegree = (float *)user_malloc(sizeof_float * zSize);
    // memset(kf->MeasurementDegree, 0, sizeof_float * zSize);
    kf->MeasurementDegree=MeasurementDegree_Temp;

    // kf->MatR_DiagonalElements = (float *)user_malloc(sizeof_float * zSize);
    // memset(kf->MatR_DiagonalElements, 0, sizeof_float * zSize);
    kf->MatR_DiagonalElements=MatR_DiagonalElements_Temp;

    // kf->StateMinVariance = (float *)user_malloc(sizeof_float * xhatSize);
    // memset(kf->StateMinVariance, 0, sizeof_float * xhatSize);
    kf->StateMinVariance=StateMinVariance_Temp;

    // kf->temp = (uint8_t *)user_malloc(sizeof(uint8_t) * zSize);
    // memset(kf->temp, 0, sizeof(uint8_t) * zSize);
    kf->temp = temp_Temp;

    // filter data
    // kf->FilteredValue = (float *)user_malloc(sizeof_float * xhatSize);
    // memset(kf->FilteredValue, 0, sizeof_float * xhatSize);
    kf->FilteredValue=FilteredValue_Temp;

    // kf->MeasuredVector = (float *)user_malloc(sizeof_float * zSize);
    // memset(kf->MeasuredVector, 0, sizeof_float * zSize);
    kf->MeasuredVector=MeasuredVector_Temp;
    // kf->ControlVector = (float *)user_malloc(sizeof_float * uSize);
    // memset(kf->ControlVector, 0, sizeof_float * uSize);
    kf->ControlVector=NULL;

    // xhat x(k|k)
    // kf->xhat_data = (float *)user_malloc(sizeof_float * xhatSize);
    // memset(kf->xhat_data, 0, sizeof_float * xhatSize);
    kf->xhat_data=xhat_data_Temp;
    Matrix_Init(&kf->xhat, kf->xhatSize, 1, (float *)kf->xhat_data);

    // xhatminus x(k|k-1)
    // kf->xhatminus_data = (float *)user_malloc(sizeof_float * xhatSize);
    // memset(kf->xhatminus_data, 0, sizeof_float * xhatSize);
    kf->xhatminus_data=xhatminus_data_Temp;
    Matrix_Init(&kf->xhatminus, kf->xhatSize, 1, (float *)kf->xhatminus_data);
    // if (uSize != 0)
    // {
    //     // control vector u
    //     kf->u_data = (float *)user_malloc(sizeof_float * uSize);
    //     memset(kf->u_data, 0, sizeof_float * uSize);
    //     Matrix_Init(&kf->u, kf->uSize, 1, (float *)kf->u_data);
    // }
    kf->u_data=NULL;
    // measurement vector z
    // kf->z_data = (float *)user_malloc(sizeof_float * zSize);
    // memset(kf->z_data, 0, sizeof_float * zSize);
    kf->z_data=z_data_Temp;
    Matrix_Init(&kf->z, kf->zSize, 1, (float *)kf->z_data);

    // covariance matrix P(k|k)
    // kf->P_data = (float *)user_malloc(sizeof_float * xhatSize * xhatSize);
    // memset(kf->P_data, 0, sizeof_float * xhatSize * xhatSize);
    kf->P_data=P_data_Temp;
    Matrix_Init(&kf->P, kf->xhatSize, kf->xhatSize, (float *)kf->P_data);

    // create covariance matrix P(k|k-1)
    // kf->Pminus_data = (float *)user_malloc(sizeof_float * xhatSize * xhatSize);
    // memset(kf->Pminus_data, 0, sizeof_float * xhatSize * xhatSize);
    kf->Pminus_data=Pminus_data_Temp;
    Matrix_Init(&kf->Pminus, kf->xhatSize, kf->xhatSize, (float *)kf->Pminus_data);

    // state transition matrix F FT
    // kf->F_data = (float *)user_malloc(sizeof_float * xhatSize * xhatSize);
    // kf->FT_data = (float *)user_malloc(sizeof_float * xhatSize * xhatSize);
    // memset(kf->F_data, 0, sizeof_float * xhatSize * xhatSize);
    // memset(kf->FT_data, 0, sizeof_float * xhatSize * xhatSize);
    kf->F_data=F_data_Temp;
    kf->FT_data=FT_data_Temp;
    Matrix_Init(&kf->F, kf->xhatSize, kf->xhatSize, (float *)kf->F_data);
    Matrix_Init(&kf->FT, kf->xhatSize, kf->xhatSize, (float *)kf->FT_data);

    // if (uSize != 0)
    // {
    //     // control matrix B
    //     kf->B_data = (float *)user_malloc(sizeof_float * xhatSize * uSize);
    //     memset(kf->B_data, 0, sizeof_float * xhatSize * uSize);
    //     Matrix_Init(&kf->B, kf->xhatSize, kf->uSize, (float *)kf->B_data);
    // }
    kf->B_data=NULL;
    // measurement matrix H
    // kf->H_data = (float *)user_malloc(sizeof_float * zSize * xhatSize);
    // kf->HT_data = (float *)user_malloc(sizeof_float * xhatSize * zSize);
    // memset(kf->H_data, 0, sizeof_float * zSize * xhatSize);
    // memset(kf->HT_data, 0, sizeof_float * xhatSize * zSize);
    kf->H_data=H_data_Temp;
    kf->HT_data=HT_data_Temp;
    Matrix_Init(&kf->H, kf->zSize, kf->xhatSize, (float *)kf->H_data);
    Matrix_Init(&kf->HT, kf->xhatSize, kf->zSize, (float *)kf->HT_data);
    // process noise covariance matrix Q
    // kf->Q_data = (float *)user_malloc(sizeof_float * xhatSize * xhatSize);
    // memset(kf->Q_data, 0, sizeof_float * xhatSize * xhatSize);
    kf->Q_data=Q_data_Temp;
    Matrix_Init(&kf->Q, kf->xhatSize, kf->xhatSize, (float *)kf->Q_data);

    // measurement noise covariance matrix R
    // kf->R_data = (float *)user_malloc(sizeof_float * zSize * zSize);
    // memset(kf->R_data, 0, sizeof_float * zSize * zSize);
    kf->R_data=R_data_Temp;
    Matrix_Init(&kf->R, kf->zSize, kf->zSize, (float *)kf->R_data);

    // kalman gain K
    // kf->K_data = (float *)user_malloc(sizeof_float * xhatSize * zSize);
    // memset(kf->K_data, 0, sizeof_float * xhatSize * zSize);
    kf->K_data=K_data_Temp;
    Matrix_Init(&kf->K, kf->xhatSize, kf->zSize, (float *)kf->K_data);

    // kf->S_data = (float *)user_malloc(sizeof_float * kf->xhatSize * kf->xhatSize);
    // memset(kf->S_data, 0, sizeof_float * kf->xhatSize * kf->xhatSize);
    kf->S_data=S_data_Temp;
    // kf->temp_matrix_data = (float *)user_malloc(sizeof_float * kf->xhatSize * kf->xhatSize);
    // memset(kf->temp_matrix_data, 0, sizeof_float * kf->xhatSize * kf->xhatSize);
    kf->temp_matrix_data=temp_matrix_data_Temp;
    // kf->temp_matrix_data1 = (float *)user_malloc(sizeof_float * kf->xhatSize * kf->xhatSize);
    // memset(kf->temp_matrix_data1, 0, sizeof_float * kf->xhatSize * kf->xhatSize);
    kf->temp_matrix_data1=temp_matrix_data1_Temp;
    // kf->temp_vector_data = (float *)user_malloc(sizeof_float * kf->xhatSize);
    // memset(kf->temp_vector_data, 0, sizeof_float * kf->xhatSize);
    kf->temp_vector_data=temp_vector_data_Temp;
    // kf->temp_vector_data1 = (float *)user_malloc(sizeof_float * kf->xhatSize);
    // memset(kf->temp_vector_data1, 0, sizeof_float * kf->xhatSize);
    kf->temp_vector_data1=temp_vector_data1_Temp;

    Matrix_Init(&kf->S, kf->xhatSize, kf->xhatSize, (float *)kf->S_data);
    Matrix_Init(&kf->temp_matrix, kf->xhatSize, kf->xhatSize, (float *)kf->temp_matrix_data);
    Matrix_Init(&kf->temp_matrix1, kf->xhatSize, kf->xhatSize, (float *)kf->temp_matrix_data1);
    Matrix_Init(&kf->temp_vector, kf->xhatSize, 1, (float *)kf->temp_vector_data);
    Matrix_Init(&kf->temp_vector1, kf->xhatSize, 1, (float *)kf->temp_vector_data1);

    kf->SkipEq1 = 0;
    kf->SkipEq2 = 0;
    kf->SkipEq3 = 0;
    kf->SkipEq4 = 0;
    kf->SkipEq5 = 0;
}

void Kalman_Filter_Reset(KalmanFilter_t *kf, uint8_t xhatSize, uint8_t uSize, uint8_t zSize)
{
    memset(kf->MeasurementMap, 0, sizeof(uint8_t) * zSize);
    memset(kf->MeasurementDegree, 0, sizeof_float * zSize);
    memset(kf->MatR_DiagonalElements, 0, sizeof_float * zSize);
    memset(kf->StateMinVariance, 0, sizeof_float * xhatSize);
    memset(kf->temp, 0, sizeof(uint8_t) * zSize);

    memset(kf->FilteredValue, 0, sizeof_float * xhatSize);
    memset(kf->MeasuredVector, 0, sizeof_float * zSize);
    // memset(kf->ControlVector, 0, sizeof_float * uSize);

    memset(kf->xhat_data, 0, sizeof_float * xhatSize);

    memset(kf->xhatminus_data, 0, sizeof_float * xhatSize);

    if(uSize != 0)
    {memset(kf->u_data, 0, sizeof_float * uSize);}

    memset(kf->z_data, 0, sizeof_float * zSize);

    memset(kf->P_data, 0, sizeof_float * xhatSize * xhatSize);

    memset(kf->Pminus_data, 0, sizeof_float * xhatSize * xhatSize);

    memset(kf->F_data, 0, sizeof_float * xhatSize * xhatSize);
    memset(kf->FT_data, 0, sizeof_float * xhatSize * xhatSize);

    if(uSize != 0)
    {memset(kf->B_data, 0, sizeof_float * xhatSize * uSize);}

    memset(kf->H_data, 0, sizeof_float * zSize * xhatSize);
    memset(kf->HT_data, 0, sizeof_float * xhatSize * zSize);

    memset(kf->Q_data, 0, sizeof_float * xhatSize * xhatSize);

    memset(kf->R_data, 0, sizeof_float * zSize * zSize);

    memset(kf->K_data, 0, sizeof_float * xhatSize * zSize);

    kf->SkipEq1 = 0;
    kf->SkipEq2 = 0;
    kf->SkipEq3 = 0;
    kf->SkipEq4 = 0;
    kf->SkipEq5 = 0;
}


void Kalman_Filter_Measure(KalmanFilter_t *kf)
{
    // ����H K R������������Զ�����
    // matrix H K R auto adjustment
    if (kf->UseAutoAdjustment != 0)
    {
        H_K_R_Adjustment(kf);
    }
    else
    {
        memcpy(kf->z_data, kf->MeasuredVector, sizeof_float * kf->zSize);
        memset(kf->MeasuredVector, 0, sizeof_float * kf->zSize);
    }

    // memcpy(kf->u_data, kf->ControlVector, sizeof_float * kf->uSize);
}

void Kalman_Filter_xhatMinusUpdate(KalmanFilter_t *kf)
{
    if (!kf->SkipEq1)
    {
        //kf->uSize is still 0
//        if (kf->uSize > 0)
//        {
//            kf->temp_vector.numRows = kf->xhatSize;
//            kf->temp_vector.numCols = 1;
//            kf->MatStatus = Matrix_Multiply(&kf->F, &kf->xhat, &kf->temp_vector);
//            kf->temp_vector1.numRows = kf->xhatSize;
//            kf->temp_vector1.numCols = 1;
//            kf->MatStatus = Matrix_Multiply(&kf->B, &kf->u, &kf->temp_vector1);
//            kf->MatStatus = Matrix_Add(&kf->temp_vector, &kf->temp_vector1, &kf->xhatminus);
//        }
//        else
        {
            kf->MatStatus = Matrix_Multiply(&kf->F, &kf->xhat, &kf->xhatminus);
        }
    }
}

void Kalman_Filter_PminusUpdate(KalmanFilter_t *kf)
{
    if (!kf->SkipEq2)
    {
        kf->MatStatus = Matrix_Transpose(&kf->F, &kf->FT);
        kf->MatStatus = Matrix_Multiply(&kf->F, &kf->P, &kf->Pminus);
        kf->temp_matrix.numRows = kf->Pminus.numRows;
        kf->temp_matrix.numCols = kf->FT.numCols;
        kf->MatStatus = Matrix_Multiply(&kf->Pminus, &kf->FT, &kf->temp_matrix); // temp_matrix = F P(k-1) FT
        kf->MatStatus = Matrix_Add(&kf->temp_matrix, &kf->Q, &kf->Pminus);
    }
}
void Kalman_Filter_SetK(KalmanFilter_t *kf)
{
    if (!kf->SkipEq3)
    {
        kf->MatStatus = Matrix_Transpose(&kf->H, &kf->HT); // z|x => x|z
        kf->temp_matrix.numRows = kf->H.numRows;
        kf->temp_matrix.numCols = kf->Pminus.numCols;
        kf->MatStatus = Matrix_Multiply(&kf->H, &kf->Pminus, &kf->temp_matrix); // temp_matrix = H��P'(k)
        kf->temp_matrix1.numRows = kf->temp_matrix.numRows;
        kf->temp_matrix1.numCols = kf->HT.numCols;
        kf->MatStatus = Matrix_Multiply(&kf->temp_matrix, &kf->HT, &kf->temp_matrix1); // temp_matrix1 = H��P'(k)��HT
        kf->S.numRows = kf->R.numRows;
        kf->S.numCols = kf->R.numCols;
        kf->MatStatus = Matrix_Add(&kf->temp_matrix1, &kf->R, &kf->S); // S = H P'(k) HT + R
        kf->MatStatus = Matrix_Inverse(&kf->S, &kf->temp_matrix1);     // temp_matrix1 = inv(H��P'(k)��HT + R)
        kf->temp_matrix.numRows = kf->Pminus.numRows;
        kf->temp_matrix.numCols = kf->HT.numCols;
        kf->MatStatus = Matrix_Multiply(&kf->Pminus, &kf->HT, &kf->temp_matrix); // temp_matrix = P'(k)��HT
        kf->MatStatus = Matrix_Multiply(&kf->temp_matrix, &kf->temp_matrix1, &kf->K);
    }
}
void Kalman_Filter_xhatUpdate(KalmanFilter_t *kf)
{
    if (!kf->SkipEq4)
    {
        kf->temp_vector.numRows = kf->H.numRows;
        kf->temp_vector.numCols = 1;
        kf->MatStatus = Matrix_Multiply(&kf->H, &kf->xhatminus, &kf->temp_vector); // temp_vector = H xhat'(k)
        kf->temp_vector1.numRows = kf->z.numRows;
        kf->temp_vector1.numCols = 1;
        kf->MatStatus = Matrix_Subtract(&kf->z, &kf->temp_vector, &kf->temp_vector1); // temp_vector1 = z(k) - H��xhat'(k)
        kf->temp_vector.numRows = kf->K.numRows;
        kf->temp_vector.numCols = 1;
        kf->MatStatus = Matrix_Multiply(&kf->K, &kf->temp_vector1, &kf->temp_vector); // temp_vector = K(k)��(z(k) - H��xhat'(k))
        kf->MatStatus = Matrix_Add(&kf->xhatminus, &kf->temp_vector, &kf->xhat);
    }
}
void Kalman_Filter_P_Update(KalmanFilter_t *kf)
{
    if (!kf->SkipEq5)
    {
        kf->temp_matrix.numRows = kf->K.numRows;
        kf->temp_matrix.numCols = kf->H.numCols;
        kf->temp_matrix1.numRows = kf->temp_matrix.numRows;
        kf->temp_matrix1.numCols = kf->Pminus.numCols;
        kf->MatStatus = Matrix_Multiply(&kf->K, &kf->H, &kf->temp_matrix);                 // temp_matrix = K(k)��H
        kf->MatStatus = Matrix_Multiply(&kf->temp_matrix, &kf->Pminus, &kf->temp_matrix1); // temp_matrix1 = K(k)��H��P'(k)
        kf->MatStatus = Matrix_Subtract(&kf->Pminus, &kf->temp_matrix1, &kf->P);
    }
}

/**
 * @brief ִ�п������˲��ƽ���ʽ,�ṩ���û����庯��,�����������е�����һ������,����������չΪEKF/UKF/ESKF/AUKF��
 *
 * @param kf kf���Ͷ���
 * @return float* �����˲�ֵ
 */
float *Kalman_Filter_Update(KalmanFilter_t *kf)
{
    // 0. ��ȡ������Ϣ
    Kalman_Filter_Measure(kf);
    if (kf->User_Func0_f != NULL)
        kf->User_Func0_f(kf);

    // �������
    // 1. xhat'(k)= A��xhat(k-1) + B��u
    Kalman_Filter_xhatMinusUpdate(kf);
    if (kf->User_Func1_f != NULL)
        kf->User_Func1_f(kf);

    // Ԥ�����
    // 2. P'(k) = A��P(k-1)��AT + Q
    Kalman_Filter_PminusUpdate(kf);
    if (kf->User_Func2_f != NULL)
        kf->User_Func2_f(kf);

    if (kf->MeasurementValidNum != 0 || kf->UseAutoAdjustment == 0)
    {
        // �������
        // 3. K(k) = P'(k)��HT / (H��P'(k)��HT + R)
        Kalman_Filter_SetK(kf);

        if (kf->User_Func3_f != NULL)
            kf->User_Func3_f(kf);

        // �ں�
        // 4. xhat(k) = xhat'(k) + K(k)��(z(k) - H��xhat'(k))
        Kalman_Filter_xhatUpdate(kf);

        if (kf->User_Func4_f != NULL)
            kf->User_Func4_f(kf);

        // ��������
        // 5. P(k) = (1-K(k)��H)��P'(k) ==> P(k) = P'(k)-K(k)��H��P'(k)
        Kalman_Filter_P_Update(kf);
    }
    else
    {
        // ����Ч����,��Ԥ��
        // xhat(k) = xhat'(k)
        // P(k) = P'(k)
        memcpy(kf->xhat_data, kf->xhatminus_data, sizeof_float * kf->xhatSize);
        memcpy(kf->P_data, kf->Pminus_data, sizeof_float * kf->xhatSize * kf->xhatSize);
    }

    // �Զ��庯��,�����ṩ������
    if (kf->User_Func5_f != NULL)
        kf->User_Func5_f(kf);

    // �����˲�����������
    // suppress filter excessive convergence
    for (uint8_t i = 0; i < kf->xhatSize; i++)
    {
        if (kf->P_data[i * kf->xhatSize + i] < kf->StateMinVariance[i])
            kf->P_data[i * kf->xhatSize + i] = kf->StateMinVariance[i];
    }

    memcpy(kf->FilteredValue, kf->xhat_data, sizeof_float * kf->xhatSize);

    if (kf->User_Func6_f != NULL)
    {
        kf->User_Func6_f(kf);
    }
    return kf->FilteredValue;
}

static inline void H_K_R_Adjustment(KalmanFilter_t *kf)
{
    kf->MeasurementValidNum = 0;

    memcpy(kf->z_data, kf->MeasuredVector, sizeof_float * kf->zSize);
    memset(kf->MeasuredVector, 0, sizeof_float * kf->zSize);

    // ʶ������������Ч�Բ���������H R K
    // recognize measurement validity and adjust matrices H R K
    memset(kf->R_data, 0, sizeof_float * kf->zSize * kf->zSize);
    memset(kf->H_data, 0, sizeof_float * kf->xhatSize * kf->zSize);
    for (uint8_t i = 0; i < kf->zSize; i++)
    {
        if (kf->z_data[i] != 0)
        {
            // �ع�����z
            // rebuild vector z
            kf->z_data[kf->MeasurementValidNum] = kf->z_data[i];
            kf->temp[kf->MeasurementValidNum] = i;
            // �ع�����H
            // rebuild matrix H
            kf->H_data[kf->xhatSize * kf->MeasurementValidNum + kf->MeasurementMap[i] - 1] = kf->MeasurementDegree[i];
            kf->MeasurementValidNum++;
        }
    }
    for (uint8_t i = 0; i < kf->MeasurementValidNum; i++)
    {
        // �ع�����R
        // rebuild matrix R
        kf->R_data[i * kf->MeasurementValidNum + i] = kf->MatR_DiagonalElements[kf->temp[i]];
    }

    // ��������ά��
    // adjust the dimensions of system matrices
    kf->H.numRows = kf->MeasurementValidNum;
    kf->H.numCols = kf->xhatSize;
    kf->HT.numRows = kf->xhatSize;
    kf->HT.numCols = kf->MeasurementValidNum;
    kf->R.numRows = kf->MeasurementValidNum;
    kf->R.numCols = kf->MeasurementValidNum;
    kf->K.numRows = kf->xhatSize;
    kf->K.numCols = kf->MeasurementValidNum;
    kf->z.numRows = kf->MeasurementValidNum;
}

