/*
 * vmc.c
 *
 *  Created on: 2024��12��3��
 *      Author: Administrator
 */
#include "vmc.h"


/**
 * @brief�������µ����꣬�˶�ѧ����������
 *
 * @note �Ҳ���ͼ
 *  ___x
 * |    1  _____  4
 * |y     /     \
 *      2 \     / 3
 *         \   /
 *          \./
 *           5
 *
 */




float servo_motor_duty1 = 90.0;                                                  // ��������Ƕ�
float servo_motor_duty2 = 90.0;                                                  // ��������Ƕ�
float servo_motor_duty3 = 90.0;                                                  // ��������Ƕ�
float servo_motor_duty4 = 90.0;                                                  // ��������Ƕ�
float servo_motor_dir = 1;                                                      // �������״̬
float E_H = 0.0;
float Stab_roll = 0.0;
float Ex_roll = 0.0;

IKparam IKParam;
int16_t alphaLeftToAngle,betaLeftToAngle,alphaRightToAngle,betaRightToAngle;

uint16 jumptime = 0;
uint16 jumptime0 = 0;
uint16 jumptime1 = 0;
uint16 jumptime2 = 0;
uint8 jump_mode = 0;
uint8 jump_cnt =0;
float speed_k = 0.0;

/*-------------------------------------------------------------------------------------------------------------------
  @brief     ��ʼ���ĸ���
  @note
-------------------------------------------------------------------------------------------------------------------*/
void SERVO_init()
{
    pwm_init(SERVO_MOTOR_PWM1, SERVO_MOTOR_FREQ, 0); //
    pwm_init(SERVO_MOTOR_PWM2, SERVO_MOTOR_FREQ, 0); //
    pwm_init(SERVO_MOTOR_PWM3, SERVO_MOTOR_FREQ, 0); //
    pwm_init(SERVO_MOTOR_PWM4, SERVO_MOTOR_FREQ, 0); //
}


/*-------------------------------------------------------------------------------------------------------------------
  @brief     �Ȳ�����
  @note
-------------------------------------------------------------------------------------------------------------------*/
void inverseKinematics(){
  float alpha1,alpha2,beta1,beta2;
  uint16_t servoLeftFront,servoLeftRear,servoRightFront,servoRightRear;
  uint32 servoLeftFrontPwm,servoLeftRearPwm,servoRightFrontPwm,servoRightRearPwm;


  if(Ramp_Flag == 1)
  {
      speed_k = 20.0;
  }
  else if(Ramp_End_Flag == 1)
  {
      speed_k = 20.0;
  }
  else if(SingleBridge_Flag == 1)
  {
      speed_k = 10.0;
  }
  else if(Jumpbarrier_Flag==1)
  {
      speed_k = 20.0;
  }
  else
  {
      speed_k = 5.0;
  }

  IKParam.XLeft = IKParam.XLeft + (motor_pwm+18 - IKParam.XLeft)/speed_k;//5
//  IKParam.XLeft =  18 + motor_pwm ;
  if(IKParam.XLeft >85) IKParam.XLeft=85;
  else if(IKParam.XLeft<-55) IKParam.XLeft=-55;

  IKParam.XRight = IKParam.XRight + (motor_pwm+18 - IKParam.XRight)/speed_k;
//  IKParam.XRight =  18 + motor_pwm;
  if(IKParam.XRight >85) IKParam.XRight=85;
  else if(IKParam.XRight<-55) IKParam.XRight=-55;

  if(Jumpbarrier_Flag==1)
  {
      jumptime0++;
      IKParam.YLeft = 40;
      IKParam.YRight = 40;
      if(jumptime0>=5)//5
      {
          jumptime1++;
          IKParam.YLeft = 145;
          IKParam.YRight = 145;
          if(jumptime1>=15)//15
          {
              Jumpbarrier_mode = 2;
              jumptime2++;
              IKParam.YLeft = 50;
              IKParam.YRight = 50;
              if(jumptime2>=100)//80
              {
                  jumptime0 = 0;
                  jumptime1 = 0;
                  jumptime2 = 0;
                  Jumpbarrier_Flag = 0;
                  Jumpbarrier_mode = 0;
//                  stop_flag = 1;
              }
          }
      }
  }
  else if(SingleBridge_Flag==1)
  {
      Ex_roll = balance_rollangle_PI( QEKF_INS.Roll , -2.0)  ;
//      Ex_roll = (-2.0 - QEKF_INS.Roll)*3.0;

      IKParam.YLeft = IKParam.YLeft + (60.0-Ex_roll - IKParam.YLeft)/10.0;
      IKParam.YRight = IKParam.YRight + (60.0+Ex_roll  - IKParam.YRight)/10.0;


      if(IKParam.YLeft >145) IKParam.YLeft=145;
      else if(IKParam.YLeft<40) IKParam.YLeft=40;
      if(IKParam.YRight >145) IKParam.YRight=145;
      else if(IKParam.YRight<40) IKParam.YRight=40;
  }
  else
  {
      IKParam.YLeft = IKParam.YLeft + (40.0+lora3a22_uart_transfer.joystick[3]/20.0 - IKParam.YLeft)/5.0;//
      if(IKParam.YLeft >155) IKParam.YLeft=155;
      else if(IKParam.YLeft<40) IKParam.YLeft=40;

      IKParam.YRight = IKParam.YRight + (40.0+lora3a22_uart_transfer.joystick[3]/20.0  - IKParam.YRight)/5.0;//
      if(IKParam.YRight >155) IKParam.YRight=155;
      else if(IKParam.YRight<40) IKParam.YRight=40;
  }


  float aLeft = 2 * IKParam.XLeft * L1;
  float bLeft = 2 * IKParam.YLeft * L1;
  float cLeft = IKParam.XLeft * IKParam.XLeft + IKParam.YLeft * IKParam.YLeft + L1 * L1 - L2 * L2;
  float dLeft = 2 * L4 * (IKParam.XLeft - L5);
  float eLeft = 2 * L4 * IKParam.YLeft;
  float fLeft = ((IKParam.XLeft - L5) * (IKParam.XLeft - L5) + L4 * L4 + IKParam.YLeft * IKParam.YLeft - L3 * L3);

  alpha1 = 2 * atan((bLeft + sqrt((aLeft * aLeft) + (bLeft * bLeft) - (cLeft * cLeft))) / (aLeft + cLeft));
  alpha2 = 2 * atan((bLeft - sqrt((aLeft * aLeft) + (bLeft * bLeft) - (cLeft * cLeft))) / (aLeft + cLeft));
  beta1 = 2 * atan((eLeft + sqrt((dLeft * dLeft) + eLeft * eLeft - (fLeft * fLeft))) / (dLeft + fLeft));
  beta2 = 2 * atan((eLeft - sqrt((dLeft * dLeft) + eLeft * eLeft - (fLeft * fLeft))) / (dLeft + fLeft));

  alpha1 = (alpha1 >= 0)?alpha1:(alpha1 + 2 * PI);
  alpha2 = (alpha2 >= 0)?alpha2:(alpha2 + 2 * PI);

  if(alpha1 >= PI/4) IKParam.alphaLeft = alpha1;
  else IKParam.alphaLeft = alpha2;
  if(beta1 >= 0 && beta1 <= PI/4) IKParam.betaLeft = beta1;
  else IKParam.betaLeft = beta2;

  float aRight = 2 * IKParam.XRight * L1;
  float bRight = 2 * IKParam.YRight * L1;
  float cRight = IKParam.XRight * IKParam.XRight + IKParam.YRight * IKParam.YRight + L1 * L1 - L2 * L2;
  float dRight = 2 * L4 * (IKParam.XRight - L5);
  float eRight = 2 * L4 * IKParam.YRight;
  float fRight = ((IKParam.XRight - L5) * (IKParam.XRight - L5) + L4 * L4 + IKParam.YRight * IKParam.YRight - L3 * L3);

  IKParam.alphaRight = 2 * atan((bRight + sqrt((aRight * aRight) + (bRight * bRight) - (cRight * cRight))) / (aRight + cRight));
  IKParam.betaRight = 2 * atan((eRight - sqrt((dRight * dRight) + eRight * eRight - (fRight * fRight))) / (dRight + fRight));

  alpha1 = 2 * atan((bRight + sqrt((aRight * aRight) + (bRight * bRight) - (cRight * cRight))) / (aRight + cRight));
  alpha2 = 2 * atan((bRight - sqrt((aRight * aRight) + (bRight * bRight) - (cRight * cRight))) / (aRight + cRight));
  beta1 = 2 * atan((eRight + sqrt((dRight * dRight) + eRight * eRight - (fRight * fRight))) / (dRight + fRight));
  beta2 = 2 * atan((eRight - sqrt((dRight * dRight) + eRight * eRight - (fRight * fRight))) / (dRight + fRight));

  alpha1 = (alpha1 >= 0)?alpha1:(alpha1 + 2 * PI);
  alpha2 = (alpha2 >= 0)?alpha2:(alpha2 + 2 * PI);

  if(alpha1 >= PI/4) IKParam.alphaRight = alpha1;
  else IKParam.alphaRight = alpha2;
  if(beta1 >= 0 && beta1 <= PI/4) IKParam.betaRight = beta1;
  else IKParam.betaRight = beta2;

  alphaLeftToAngle = (int)((IKParam.alphaLeft / 6.28) * 360);//����ת�Ƕ�
  betaLeftToAngle = (int)((IKParam.betaLeft / 6.28) * 360);

  alphaRightToAngle = (int)((IKParam.alphaRight / 6.28) * 360);
  betaRightToAngle = (int)((IKParam.betaRight / 6.28) * 360);

  servoLeftFront = 90 + betaLeftToAngle;
  servoLeftRear =  alphaLeftToAngle-90;
  servoRightFront = 90 - betaRightToAngle;
  servoRightRear = 270 - alphaRightToAngle;

  servoLeftFrontPwm=SERVO_MOTOR_DUTY(servoLeftFront);
  if(servoLeftFrontPwm>=9999) servoLeftFrontPwm=9999;

  servoLeftRearPwm =SERVO_MOTOR_DUTY(servoLeftRear);
  if(servoLeftRearPwm>=9999) servoLeftRearPwm=9999;

  servoRightFrontPwm=SERVO_MOTOR_DUTY(servoRightFront);
  if(servoRightFrontPwm>=9999) servoRightFrontPwm=9999;

  servoRightRearPwm=SERVO_MOTOR_DUTY(servoRightRear);
  if(servoRightRearPwm>=9999) servoRightRearPwm=9999;

    pwm_set_duty(SERVO_MOTOR_PWM1, servoRightRearPwm);
    pwm_set_duty(SERVO_MOTOR_PWM2, servoRightFrontPwm);
    pwm_set_duty(SERVO_MOTOR_PWM3, servoLeftRearPwm);
    pwm_set_duty(SERVO_MOTOR_PWM4, servoLeftFrontPwm);

}









