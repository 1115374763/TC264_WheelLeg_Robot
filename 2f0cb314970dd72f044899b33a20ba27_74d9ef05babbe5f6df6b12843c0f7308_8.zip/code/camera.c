#include "zf_common_headfile.h"
#include "math.h"

float Err;
uint8 L_start_y = 0;//��ʼ��
uint8 L_start_x = 0;
uint8 R_start_y = 0;
uint8 R_start_x = 0;

uint8 wx[MT9V03X_H]={0};
/*-------------------------------------------------------------------------------------------------------------------
  @brief     ���߻�ȡ
  @note
-------------------------------------------------------------------------------------------------------------------*/
void Midline_get()
{
    int i;
    int pingyizhuxian;
    for(i=MT9V03X_H-2;i>1;i--)
    {
        wx[i]=( zx[i]+yx[i] )/2;//��������
    }

//    if(circle_flag!=1&&Cross_Flag!=1&&Barrier_Flag!=1&&Zebra_Flag!=1&&Ramp_Flag!=1&&SingleBridge_Flag!=1&&Ramp_End_Flag!=1&&Jumpbarrier_Flag!=1)//Ԫ�ػ���
//    {
//        if(Left_Lost_Time>=2&&Right_Lost_Time==0)//���� ͨ���ұ߽�ƫ��
//        {
//            for(int i=Boundry_Startlost_Left;i>Finnalline;i--)
//             {
//                if(yx[i]-Half_zhidao_width[i]-20>=2)
//                    wx[i]=yx[i]-Half_zhidao_width[i]-20;
//                else wx[i]=2;
//             }
//        }
//        if(Right_Lost_Time>=2&&Left_Lost_Time==0)//���� ͨ����߽�ƫ��
//        {
//            for(int i=Boundry_Startlost_right;i>Finnalline;i--)
//             {
//                if(zx[i]+Half_zhidao_width[i]+20<=MT9V03X_W-3)
//                    wx[i]=zx[i]+Half_zhidao_width[i]+20;
//                else wx[i]=MT9V03X_W-3;
//             }
//        }
//    }

    for(i=Finnalline;i>1;i--)
    {
        pingyizhuxian=Finnalline+3;
        if(pingyizhuxian>=MT9V03X_H-3) pingyizhuxian=MT9V03X_H-3;
        wx[i]=wx[pingyizhuxian];
    }
}

//�������ֵ
uint8 Threshold = 0;
uint8 Threshold_Lup = 0;
uint8 Threshold_Rup = 0;
//-------------------------------------------------------------------------------------------------------------------
//  @brief      qiqi���Ŀ��ٴ��
//  @return     uint8
//  @since      v1.1
//  Sample usage:   OTSU_Threshold = otsuThreshold(mt9v03x_image,0,MT9V03X_H,0,MT9V03X_W);
//-------------------------------------------------------------------------------------------------------------------
uint8 otsuThreshold(uint8 *ima,uint8 h_start,uint8 h_end,uint8 w_start,uint8 w_end)   //ע�������ֵ��һ��Ҫ��ԭͼ��
{
    #define GrayScale 256
    int Pixel_Max=0;
    int Pixel_Min=255;
    int pixelCount[GrayScale];
    float pixelPro[GrayScale];
    int i, j, pixelSum = (w_end-w_start) * (h_end-h_start)/4;
    uint8 threshold = 0;
    uint8* data = ima;  //ָ���������ݵ�ָ��
    for (i = 0; i < GrayScale; i++)
    {
        pixelCount[i] = 0;
        pixelPro[i] = 0;
    }

    uint32 gray_sum=0;
    //ͳ�ƻҶȼ���ÿ������������ͼ���еĸ���
    for (i = h_start; i < h_end; i+=2)
    {
        for (j = w_start; j < w_end; j+=2)
        {
            pixelCount[(int)data[i * MT9V03X_W + j]]++;  //����ǰ�ĵ������ֵ��Ϊ����������±�
            gray_sum+=(int)data[i * MT9V03X_W + j];       //�Ҷ�ֵ�ܺ�
            if(data[i * MT9V03X_W + j]>Pixel_Max)   Pixel_Max=data[i * MT9V03X_W + j];
            if(data[i * MT9V03X_W + j]<Pixel_Min)   Pixel_Min=data[i * MT9V03X_W + j];
        }
    }

    //����ÿ������ֵ�ĵ�������ͼ���еı���

    for (i = Pixel_Min; i < Pixel_Max; i++)
    {
        pixelPro[i] = (float)pixelCount[i] / pixelSum;

    }

    //�����Ҷȼ�[0,255]
    float w0, w1, u0tmp, u1tmp, u0, u1, u, deltaTmp, deltaMax = 0;

    w0 = w1 = u0tmp = u1tmp = u0 = u1 = u = deltaTmp = 0;
    for (j = Pixel_Min; j < Pixel_Max; j++)
    {

        w0 += pixelPro[j];  //��������ÿ���Ҷ�ֵ�����ص���ռ����֮��   ���������ֵı���
        u0tmp += j * pixelPro[j];  //�������� ÿ���Ҷ�ֵ�ĵ�ı��� *�Ҷ�ֵ

        w1=1-w0;
        u1tmp=gray_sum/pixelSum-u0tmp;

        u0 = u0tmp / w0;              //����ƽ���Ҷ�
        u1 = u1tmp / w1;              //ǰ��ƽ���Ҷ�
        u = u0tmp + u1tmp;            //ȫ��ƽ���Ҷ�
        deltaTmp = (float)(w0 *w1* (u0 - u1)* (u0 - u1)) ;
        if (deltaTmp > deltaMax)
        {
            deltaMax = deltaTmp;
            threshold = j;
        }
        if (deltaTmp < deltaMax)
        {
            break;
        }

    }

        if(threshold>255)
               threshold=255;
        if(threshold<0)
               threshold=0;

    return threshold;
}




/*-------------------------------------------------------------------------------------------------------------------
  @brief     ��ֵ��
  @note
-------------------------------------------------------------------------------------------------------------------*/
//��ֵ������
uint8 image[MT9V03X_H][MT9V03X_W];
void ZeroOne(uint8 *ima,uint8 h_start,uint8 height,uint8 w_start,uint8 width,uint8 yuzhi)
{
    uint8* data = ima;  //ָ���������ݵ�ָ��
    for(uint8 i=h_start;i<height;i++)
    {
        for(uint8 j=w_start;j<width;j++)
        {
            if(data[i*MT9V03X_W+j]>=yuzhi) image[i][j]=255;//��
            else image[i][j]=0;//��
        }
    }
//    if(circle_flag!=1&&Cross_Flag!=1&&Barrier_Flag!=1&&Zebra_Flag!=1&&Ramp_Flag!=1&&SingleBridge_Flag!=1&&Ramp_End_Flag!=1&&Jumpbarrier_Flag!=1)
//    {
//        for(uint8 i=h_start;i<20;i++)
//        {
//            for(uint8 j=w_start;j<width;j++)
//            {
//                image[i][j]=0;
//            }
//        }
//    }
}


//�ֿ��ֵ��
void fenkuai_ZeroOne(uint8 height,uint8 width,uint8 leftyuzhi,uint8 midyuzhi,uint8 rightyuzhi)
{
    uint8 i,j;
    for(i=0;i<height;i++)
    {
        for(j=0;j<width/3;j++)
        {
            if(mt9v03x_image[i][j]>=leftyuzhi) image[i][j]=255;//��
            else image[i][j]=0;//��
        }
        for(j=width/3;j<2*width/3;j++)
        {
            if(mt9v03x_image[i][j]>=midyuzhi) image[i][j]=255;//��
            else image[i][j]=0;//��
        }
        for(j=2*width/3;j<width;j++)
        {
            if(mt9v03x_image[i][j]>=rightyuzhi) image[i][j]=255;//��
            else image[i][j]=0;//��
        }
    }
}

/*-------------------------------------------------------------------------------------------------------------------
  @brief     Ѳ��
  @note
-------------------------------------------------------------------------------------------------------------------*/
//Ѱ���ұ���
uint8 zx[MT9V03X_H]={0};
uint8 yx[MT9V03X_H]={0};
uint8 Left_Lost_Flag[MT9V03X_H],Right_Lost_Flag[MT9V03X_H];
uint8 left_border,right_border,midline;
uint8 Finnalline;
uint8 leftlost_mode;
uint8 rightlost_mode;
uint8 cross_xunxian_mode=0;
void XUNXIAN(uint8 height,uint8 width)
{
    leftlost_mode=0;
    rightlost_mode=0;
    uint8 leftpoint=0;
    uint8 rightpoint=0;
    cross_xunxian_mode=0;
    Finnalline=0;
    midline=MT9V03X_W/2; //��ʼ������Ϊ������ֵ
    volatile int White_Column[MT9V03X_W]={0};//ÿ�а��г���
    uint8 Longest_White_Column_Left[2]={0};
    uint8 Longest_White_Column_Right[2]={0};
    uint8 cnt=0;
    if(left_circle_flag==1&&circle_mode==3)
    {
        midline=MT9V03X_W/4;
    }
    if(right_circle_flag==1&&circle_mode==3)
    {
        midline=3*MT9V03X_W/4;
    }

    for(uint8 h=height-1;h>0;h--)//��������ɨ�� ����ʲ��ø�
    {
        uint8 left_cross_lost=0;
        uint8 right_cross_lost=0;
        if(h >= height-1)//�ҵ���һ�����ұ߽�
        {
            for(uint8 w=midline;w>=2;w--)
            {
                if(image[h][w-2]==0&&image[h][w-1]==0&&image[h][w]==255)
                {
                    left_border=w;
                    Left_Lost_Flag[h] = 0; //�������飬������1����������0
                    break;
                }
                else if(w<=2&&image[h][w]==255)
                {
                    leftlost_mode=1;
                    left_border=1;
                    Left_Lost_Flag[h] = 1; //�������飬������1����������0
                    break;
                }
                else if(w<=2&&image[h][w]==0)
                {
//                    leftlost_mode=2;
                    left_border=1;
                    Left_Lost_Flag[h] = 0; //�������飬������1����������0
                    break;
                }
            }
            for(uint8 w=midline;w<=width-2-1;w++)
            {
                if(image[h][w+2]==0&&image[h][w+1]==0&&image[h][w]==255)
                {
                    right_border=w;
                    Right_Lost_Flag[h] = 0; //�Ҷ������飬������1����������0
                    break;
                }
                else if(w>=width-2-1&&image[h][w]==255)
                {
                    rightlost_mode=1;
                    right_border=width-2;
                    Right_Lost_Flag[h] = 1; //�Ҷ������飬������1����������0
                    break;
                }
                else if(w>=width-2-1&&image[h][w]==0)
                {
//                    rightlost_mode=2;
                    right_border=width-2;
                    Right_Lost_Flag[h] = 0; //�Ҷ������飬������1����������0
                    break;
                }
            }
        }
        /////////////////////���������ұ߽�////////////////////
         if(h < height-1&&leftlost_mode!=2&&rightlost_mode!=2&&cross_xunxian_mode!=1)
         {
             leftpoint=left_border+5;
             if(leftpoint>width-1) leftpoint=width-1;
             for(uint8 w=leftpoint;w>=2;w--)//leftpoint
             {
                 if(image[h][w-2]==0&&image[h][w-1]==0&&image[h][w]==255)
                 {
                     left_border=w;
                     Left_Lost_Flag[h] = 0; //�������飬������1����������0
                     break;
                 }
                 else if(w<=2&&image[h][w]==255)
                 {
//                     left_cross_lost=1;
                     left_border=1;
                     Left_Lost_Flag[h] = 1; //�������飬������1����������0
                     break;
                 }
             }
             rightpoint=right_border-5;
             if(rightpoint<0) rightpoint=0;
             for(uint8 w=rightpoint;w<=width-2-1;w++)//rightpoint
             {
                 if(image[h][w+2]==0&&image[h][w+1]==0&&image[h][w]==255)
                 {
                     right_border=w;
                     Right_Lost_Flag[h] = 0; //�Ҷ������飬������1����������0
                     break;
                 }
                 else if(w>=width-2-1&&image[h][w]==255)
                 {
//                     right_cross_lost=1;
                     right_border=width-2;
                     Right_Lost_Flag[h] = 1; //�Ҷ������飬������1����������0
                     break;
                 }
             }
             if(left_cross_lost==1&&right_cross_lost==1) cross_xunxian_mode=1;
         }



        if(h <= height-1&&leftlost_mode==2)
        {//��߽��쳣
//�ҵ��ڶ������ұ߽�
            for(uint8 w=width-1;w>=2;w--)
            {
                if(image[h][w-2]==0&&image[h][w-1]==0&&image[h][w]==255)//�ڶ�����߽�
                {
                    left_border=w;
                    Left_Lost_Flag[h] = 0; //�������飬������1����������0
                    break;
                }
                else if(w<=2)
                {
                    left_border=1;
                    Left_Lost_Flag[h] = 1; //�������飬������1����������0
                    break;
                }
            }

            rightpoint=right_border-5;
            if(rightpoint<0) rightpoint=0;
            for(uint8 w=rightpoint;w<=width-2-1;w++)//�ڶ����ұ߽�
            {
                if(image[h][w+2]==0&&image[h][w+1]==0&&image[h][w]==255)
                {
                    right_border=w;
                    Right_Lost_Flag[h] = 0; //�Ҷ������飬������1����������0
                    break;
                }
                else if(w>=width-2-1)
                {
                    right_border=width-2;
                    Right_Lost_Flag[h] = 1; //�Ҷ������飬������1����������0
                    break;
                }
            }
            leftlost_mode=0;
        }

        if(h <= height-1&&rightlost_mode==2)
        {//�ұ߽��쳣
//�ҵ��ڶ������ұ߽�
            leftpoint=left_border+5;
            if(leftpoint>width-1) leftpoint=width-1;
            for(uint8 w=leftpoint;w>=2;w--)
            {
                if(image[h][w-2]==0&&image[h][w-1]==0&&image[h][w]==255)//�ڶ�����߽�
                {
                    left_border=w;
                    Left_Lost_Flag[h] = 0; //�������飬������1����������0
                    break;
                }
                else if(w<=2)
                {
                    left_border=1;
                    Left_Lost_Flag[h] = 1; //�������飬������1����������0
                    break;
                }
            }

            for(uint8 w=0;w<=width-2-1;w++)//�ڶ����ұ߽�
            {
                if(image[h][w+2]==0&&image[h][w+1]==0&&image[h][w]==255)
                {
                    right_border=w;
                    Right_Lost_Flag[h] = 0; //�Ҷ������飬������1����������0
                    break;
                }
                else if(w>=width-2-1)
                {
                    right_border=width-2;
                    Right_Lost_Flag[h] = 1; //�Ҷ������飬������1����������0
                    break;
                }
            }
            rightlost_mode=0;
        }

        zx[h]=left_border;//��߽�����
        yx[h]=right_border;//�ұ߽�����

    }
}


/*-------------------------------------------------------------------------------------------------------------------
  @brief     ֻѰһС������
  @note
-------------------------------------------------------------------------------------------------------------------*/
uint8 Longest_White_Column_Left[2]={0};
uint8 Longest_White_Column_Right[2]={0};
void XUNXIAN_MODE1(uint8 height,uint8 width)
{
    leftlost_mode=0;
    rightlost_mode=0;
    midline=MT9V03X_W/2; //��ʼ������Ϊ������ֵ
    Finnalline=5;
    uint8 leftpoint=0;
    uint8 rightpoint=0;
    uint8 h=height-1;//��ʼ��
    uint8 i,j;
    volatile int White_Column[MT9V03X_W]={0};//ÿ�а��г���
    for (i=2;i<=MT9V03X_W-2-1;i+=2)
    {
        for (j=MT9V03X_H-2;j >= 0; j--)
        {
            if(image[j][i] == 0)
                break;
            else
                White_Column[i]++;
        }
    }
    //����������������
     Longest_White_Column_Left[0] =0;
     for(i=2;i<=MT9V03X_W-2-1;i+=2)
     {
         if (Longest_White_Column_Left[0] < White_Column[i])//�������һ��
         {
             Longest_White_Column_Left[0] = White_Column[i];//��0���ǰ��г���
             Longest_White_Column_Left[1] = i;              //��1�����±꣬��j��
         }
     }

    for(uint8 w=midline;w>=2;w--)
    {
        if(image[h][w-2]==0&&image[h][w-1]==0&&image[h][w]==255)//�ںڰ�
        {
            left_border=w;
            break;
        }
        else if(w<=2&&image[h][w]==255)//��
        {
            leftlost_mode=1;
            left_border=2;
            break;
        }
        else if(w<=2&&image[h][w]==0)//��
        {
            leftlost_mode=2;
            left_border=2;
            break;
        }
    }
    for(uint8 w=midline;w<=width-2-1;w++)
    {
        if(image[h][w+2]==0&&image[h][w+1]==0&&image[h][w]==255)//�ںڰ�
        {
            right_border=w;
            break;
        }
        else if(w>=width-2-1&&image[h][w]==255)//��
        {
            rightlost_mode=1;
            right_border=width-2-1;
            break;
        }
        else if(w>=width-2-1&&image[h][w]==0)//��
        {
            rightlost_mode=2;
            right_border=width-2-1;
            break;
        }
    }
    if(leftlost_mode==2)
    {//��߽��쳣
//�ҵ��ڶ������ұ߽�
        for(uint8 w=width-2-1;w>=2;w--)
        {
            if(image[h][w-2]==0&&image[h][w-1]==0&&image[h][w]==255)//�ڶ�����߽�
            {
                left_border=w;
                break;
            }
            else if(w<=2)
            {
                left_border=2;
                break;
            }
        }

        rightpoint=right_border-5;
        if(rightpoint<2) rightpoint=2;
        for(uint8 w=rightpoint;w<=width-2-1;w++)
        {
            if(image[h][w+2]==0&&image[h][w+1]==0&&image[h][w]==255)//�ڶ����ұ߽�
            {
                right_border=w;
                break;
            }
            else if(w>=width-2-1)
            {
                right_border=width-2-1;
                break;
            }
        }
        leftlost_mode=0;
    }

    if(rightlost_mode==2)
    {//�ұ߽��쳣
//�ҵ��ڶ������ұ߽�
        leftpoint=left_border+5;
        if(leftpoint>width-2-1) leftpoint=width-2-1;
        for(uint8 w=leftpoint;w>=2;w--)
        {
            if(image[h][w-2]==0&&image[h][w-1]==0&&image[h][w]==255)//�ڶ�����߽�
            {
                left_border=w;
                break;
            }
            else if(w<=2)
            {
                left_border=2;
                break;
            }
        }

        for(uint8 w=2;w<=width-2-1;w++)//�ڶ����ұ߽�
        {
            if(image[h][w+2]==0&&image[h][w+1]==0&&image[h][w]==255)//�ڶ����ұ߽�
            {
                right_border=w;
                break;
            }
            else if(w>=width-2-1)
            {
                right_border=width-2-1;
                break;
            }
        }
        rightlost_mode=0;
    }
    for(;h>0;h--)
    {
        if(h>=1&&image[h-1][ Longest_White_Column_Left[1] ]==0)
        {
            Finnalline=h;//������
            break;
        }
    }
}

void XUNXIAN_cross(uint8 height,uint8 width)
{
    int i,j;
    volatile int White_Column[MT9V03X_W]={0};//ÿ�а��г���
    uint8 Longest_White_Column_Left[2]={0};
    uint8 Longest_White_Column_Right[2]={0};
    for(i=30; i<=MT9V03X_W-30; i++)
    {
         for (j = MT9V03X_H - 5; j >= 0; j--)
         {
             if(image[j][i] == 0)
                 break;
             else
                 White_Column[i]++;
         }
    }
    Longest_White_Column_Left[0] =0;
    Longest_White_Column_Right[0] = 0;
    if(Boundry_Start_Left==MT9V03X_H-2&&Boundry_Start_Right!=MT9V03X_H-2)//������̬ƫ�� ���۰���ƫ��
    {
        for(i=MT9V03X_W/2+30;i<=MT9V03X_W-20;i++)
        {
             if (Longest_White_Column_Left[0] < White_Column[i])//�������һ��
             {
                 Longest_White_Column_Left[0] = White_Column[i];//��0���ǰ��г���
                 Longest_White_Column_Left[1] = i;              //��1�����±꣬��j��
             }
        }
        for(i=MT9V03X_W-20;i>=MT9V03X_W/2+30;i--)//��������ע���������ҵ���������λ�þͿ���ͣ��
        {
             if (Longest_White_Column_Right[0] < White_Column[i])//�������һ��
             {
                 Longest_White_Column_Right[0] = White_Column[i];//��0���ǰ��г���
                 Longest_White_Column_Right[1] = i;              //��1�����±꣬��j��
             }
        }
    }
    else if(Boundry_Start_Left!=MT9V03X_H-2&&Boundry_Start_Right==MT9V03X_H-2)//������̬ƫ�� ���۰���ƫ��
    {
        for(i=20;i<=MT9V03X_W/2-30;i++)
        {
             if (Longest_White_Column_Left[0] < White_Column[i])//�������һ��
             {
                 Longest_White_Column_Left[0] = White_Column[i];//��0���ǰ��г���
                 Longest_White_Column_Left[1] = i;              //��1�����±꣬��j��
             }
        }
        for(i=MT9V03X_W/2-30;i>=20;i--)//��������ע���������ҵ���������λ�þͿ���ͣ��
        {
             if (Longest_White_Column_Right[0] < White_Column[i])//�������һ��
             {
                 Longest_White_Column_Right[0] = White_Column[i];//��0���ǰ��г���
                 Longest_White_Column_Right[1] = i;              //��1�����±꣬��j��
             }
        }
    }
    else//������̬���� ���۰��о���
    {
        for(i=70;i<=MT9V03X_W-60;i++)
        {
             if (Longest_White_Column_Left[0] < White_Column[i])//�������һ��
             {
                 Longest_White_Column_Left[0] = White_Column[i];//��0���ǰ��г���
                 Longest_White_Column_Left[1] = i;              //��1�����±꣬��j��
             }
        }
        for(i=MT9V03X_W-70;i>=60;i--)//��������ע���������ҵ���������λ�þͿ���ͣ��
        {
             if (Longest_White_Column_Right[0] < White_Column[i])//�������һ��
             {
                 Longest_White_Column_Right[0] = White_Column[i];//��0���ǰ��г���
                 Longest_White_Column_Right[1] = i;              //��1�����±꣬��j��
             }
        }
    }

    for(uint8 h=height-1;h>0;h--)//��������ɨ�� ����ʲ��ø�
    {
        for(uint8 w=Longest_White_Column_Left[1];w>=2;w--)
        {
            if(image[h][w-2]==0&&image[h][w-1]==0&&image[h][w]==255)
            {
              left_border=w;
              Left_Lost_Flag[h] = 0; //�������飬������1����������0
              break;
            }
            else if(w<=2&&image[h][w]==255)
            {
              left_border=1;
              Left_Lost_Flag[h] = 1; //�������飬������1����������0
              break;
            }
        }
        for(uint8 w=Longest_White_Column_Right[1];w<=width-2-1;w++)
        {
            if(image[h][w+2]==0&&image[h][w+1]==0&&image[h][w]==255)
            {
              right_border=w;
              Right_Lost_Flag[h] = 0; //�Ҷ������飬������1����������0
              break;
            }
            else if(w>=width-2-1&&image[h][w]==255)
            {
              right_border=width-2;
              Right_Lost_Flag[h] = 1; //�Ҷ������飬������1����������0
              break;
            }
        }
        zx[h]=left_border;//��߽�����
        yx[h]=right_border;//�ұ߽�����
        if(h>=1&&image[h-1][ Longest_White_Column_Left[1]]==0)
        {
            Finnalline=h;//������
            break;
        }
    }
}


/*-------------------------------------------------------------------------------------------------------------------
  @brief    ����������Ϣ
  @note
-------------------------------------------------------------------------------------------------------------------*/
uint8 Left_Lost_Time,Right_Lost_Time,Both_Lost_Time,
    Boundry_Start_Left,Boundry_Start_Right,Boundry_Startlost_Left,Boundry_Startlost_right,Sum_Lost_Time;
/////����������Ϣ
void Track_Analysis()
{
    uint8 i;
    Left_Lost_Time=Right_Lost_Time=Both_Lost_Time=Sum_Lost_Time=Boundry_Start_Left
            =Boundry_Start_Right=Boundry_Startlost_Left=Boundry_Startlost_right=0;
    for (i = MT9V03X_H - 2; i > Finnalline; i--)//�������ݳ�������
      {
          if (zx[i]  == 1)//���߶�����
              Left_Lost_Time++;
          if (yx[i] == MT9V03X_W-2)
              Right_Lost_Time++;
          if (zx[i]  == 1 && yx[i] == MT9V03X_W-2)//˫�߶�����
              Both_Lost_Time++;

          if (Boundry_Startlost_Left ==  0 && zx[i]  == 1)//��¼��һ�����ߵ㣬�߽���ʼ��
              Boundry_Startlost_Left = i;
          if (Boundry_Startlost_right ==  0 && yx[i] == MT9V03X_W-2)
              Boundry_Startlost_right = i;

          if (Boundry_Start_Left ==  0 && zx[i]  != 1)//��¼��һ���Ƕ��ߵ㣬�߽���ʼ��
              Boundry_Start_Left = i;
          if (Boundry_Start_Right == 0 && yx[i] != MT9V03X_W-2)
              Boundry_Start_Right = i;
      }
//    if(Left_Lost_Time>=Right_Lost_Time)
//    {
//        Both_Lost_Time = Right_Lost_Time;
//    }
//    else
//    {
//        Both_Lost_Time = Left_Lost_Time;
//    }


}


/*-------------------------------------------------------------------------------------------------------------------
  @brief     ����ж�
  @note
-------------------------------------------------------------------------------------------------------------------*/
uint8 left_control_flag=0;
uint8 right_control_flag=0;
void is_wangdao()
{
    uint8 i;
    left_control_flag=0;
    right_control_flag=0;
    //*******************************************�ж����***********************************************************//
    //           Road_Wide[i]=Right_Line[i]-Left_Line[i];
    if(!trueshortflag)
    {
        if( (Left_Lost_Time>Right_Lost_Time)// �����Լ�һ��б�ʱ仯���� �Ǳ�Ҫ���� ������������
                &&Left_Lost_Time>20
                &&Both_Lost_Time<3
                &&Finnalline!=0
                &&Boundry_Start_Right>= Boundry_Start_Left
                                                          )
        {
           left_control_flag=1; //��ת��
        }
        if( (Right_Lost_Time>Left_Lost_Time)// �����Լ�һ��б�ʱ仯���� �Ǳ�Ҫ���� ������������
                &&Right_Lost_Time>20
                &&Both_Lost_Time<3
                &&Finnalline!=0
                &&Boundry_Start_Left>= Boundry_Start_Right
                                                          )
        {
           right_control_flag=1; //��ת��
        }

//         if(left_control_flag==1)
//         {
//             for(i=Boundry_Startlost_Left;i>0;i--)
//             {
//                if(yx[i]-Half_wangdao_width[i]>=2)
//                    wx[i]=yx[i]-Half_wangdao_width[i];
//                else wx[i]=2;
//             }
//         }
     //
//         if(right_control_flag==1)
//         {
//             for(i=Boundry_Startlost_right;i>0;i--)
//             {
//                if(zx[i]+Half_wangdao_width[i]<=MT9V03X_W-3)
//                    wx[i]=zx[i]+Half_wangdao_width[i];
//                else wx[i]=MT9V03X_W-3;
//             }
//         }
    }
}

/*-------------------------------------------------------------------------------------------------------------------
  @brief     ֱ���ж�
  @note
-------------------------------------------------------------------------------------------------------------------*/
uint8 shortflag=0;
uint8 trueshortflag=0;
void is_straight()
{
    //**********************************************�ж�ֱ��*********************************************************//
   if(!left_control_flag&&!right_control_flag)
   {
       uint8 shortwrong = 0;
       float kfirst=0;
       float ksecond=0;
       float kerror=0;
//       advanced_regression(0, 4, 8, 12, 16);
       advanced_regression(0, 25, 27, 29, 31);
       kfirst = parameterB;

//       advanced_regression(0, 18, 22, 26, 30);
       advanced_regression(0, 33, 35, 37, 39);
       ksecond = parameterB;

       if (FMy_Abs(0, kfirst) >= 0.7 || FMy_Abs(0, ksecond) >= 0.7) { shortwrong = 1; }
       kerror = FMy_Abs(kfirst, ksecond);

       if (kerror <= 0.3) shortflag = shortflag + 1;
       if (kerror > 0.3) { shortflag = 0; }
       if (shortwrong == 1) { shortflag = 0; }
       if (shortflag >= 2) { shortflag = 2; trueshortflag = 1; }
       if (shortflag < 2) trueshortflag = 0;
   }
}


/*-------------------------------------------------------------------------------------------------------------------
  @brief     ��Ϻ���
  @note
-------------------------------------------------------------------------------------------------------------------*/
float parameterB=0;
float parameterA=0;
void advanced_regression(int type, int startline1, int endline1, int startline2, int endline2) //б�ʺ���
{
    int i = 0;
    int sumlines1 = endline1 - startline1;
    int sumlines2 = endline2 - startline2;
    int sumX = 0;
    int sumY = 0;
    float averageX = 0;
    float averageY = 0;
    float sumUp = 0;
    float sumDown = 0;
    if (type == 0)  //�������
    {
        /**����sumX sumY**/
        for (i = startline1; i < endline1; i++)
        {
            sumX += i;
            sumY += wx[i];
        }
        for (i = startline2; i < endline2; i++)
        {
            sumX += i;
            sumY += wx[i];
        }
        averageX = (float)(sumX / (sumlines1 + sumlines2));     //x��ƽ��ֵ
        averageY = (float)(sumY / (sumlines1 + sumlines2));     //y��ƽ��ֵ
        for (i = startline1; i < endline1; i++)
        {
            sumUp += (wx[i] - averageY) * (i - averageX);
            sumDown += (i - averageX) * (i - averageX);
        }
        for (i = startline2; i < endline2; i++)
        {
            sumUp += (wx[i] - averageY) * (i - averageX);
            sumDown += (i - averageX) * (i - averageX);
        }
        if (sumDown == 0) parameterB = 0;
        else parameterB = sumUp / sumDown;
        parameterA = averageY - parameterB * averageX;

    }
    else if (type == 1)     //�������
    {
        /**����sumX sumY**/
        for (i = startline1; i < endline1; i++)
        {
            sumX += i;
            sumY += zx[i];
        }
        for (i = startline2; i < endline2; i++)
        {
            sumX += i;
            sumY += zx[i];
        }
        averageX = (float)(sumX / (sumlines1 + sumlines2));     //x��ƽ��ֵ
        averageY = (float)(sumY / (sumlines1 + sumlines2));     //y��ƽ��ֵ
        for (i = startline1; i < endline1; i++)
        {
            sumUp += (zx[i] - averageY) * (i - averageX);
            sumDown += (i - averageX) * (i - averageX);
        }
        for (i = startline2; i < endline2; i++)
        {
            sumUp += (zx[i] - averageY) * (i - averageX);
            sumDown += (i - averageX) * (i - averageX);
        }
        if (sumDown == 0) parameterB = 0;
        else parameterB = sumUp / sumDown;
        parameterA = averageY - parameterB * averageX;
    }
    else if (type == 2)         //�������
    {
        /**����sumX sumY**/
        for (i = startline1; i < endline1; i++)
        {
            sumX += i;
            sumY += yx[i];
        }
        for (i = startline2; i < endline2; i++)
        {
            sumX += i;
            sumY += yx[i];
        }
        averageX = (float)(sumX / (sumlines1 + sumlines2));     //x��ƽ��ֵ
        averageY = (float)(sumY / (sumlines1 + sumlines2));     //y��ƽ��ֵ
        for (i = startline1; i < endline1; i++)
        {
            sumUp += (yx[i] - averageY) * (i - averageX);
            sumDown += (i - averageX) * (i - averageX);
        }
        for (i = startline2; i < endline2; i++)
        {
            sumUp += (yx[i] - averageY) * (i - averageX);
            sumDown += (i - averageX) * (i - averageX);
        }
        if (sumDown == 0) parameterB = 0;
        else parameterB = sumUp / sumDown;
        parameterA = averageY - parameterB * averageX;
    }
}


/*-------------------------------------------------------------------------------------------------------------------
  @brief     ������֮�����ֵ�ĸ�����
  @note
-------------------------------------------------------------------------------------------------------------------*/
float FMy_Abs(float a, float b)//������֮�����ֵ�ĸ�����
{

    if ((a - b) > 0)
        return ((float)(a - b));
    else return ((float)(b - a));
}

//-------------------------------------------------------------------------------------------------------------------
//  @brief      ��ͼ�񻭺ڿ�Ϊ�Թ�����׼��
//  @return     void
//  @since      v1.0
//  Sample usage:   image_draw_rectan(Image_use);
//-------------------------------------------------------------------------------------------------------------------
void image_draw_rectan()
{
    uint8 i = 0;
    //�ֲ���ֵʱ����
    for (i = 0; i < MT9V03X_H; i++)//����1��
    {
        mt9v03x_image[i][0] = 0;
        mt9v03x_image[i][MT9V03X_W - 1] = 0;
    }
    for (i = 0; i < MT9V03X_W; i++)//����1��
    {
        mt9v03x_image[0][i] = 0;
        mt9v03x_image[MT9V03X_H-1][i] = 0;
    }
    //�ֲ���ֵʱ����


}
void image_draw_rectan_zeroone()
{
    uint8 i = 0;
    //��ֵ���Թ���ʱ����
    for (i = 0; i < MT9V03X_H; i++)
    {
        image[i][0] = 0;
        image[i][MT9V03X_W - 1] = 0;
    }
    for (i = 0; i < MT9V03X_W; i++)
    {
        image[0][i] = 0;
        image[MT9V03X_H-1][i] = 0;
    }
    //��ֵ���Թ���ʱ����
}

/*---------------------------------------------------------------
 ����    ����search_neighborhood �ֲ���ֵ��
 ����    �ܡ��Թ����ұ߽�
 ����    ������
 ���� �� ֵ����
 ��ע�����
 ----------------------------------------------------------------*/
struct LEFT_EDGE
{
    int16 row;  //������
    int16 col;  //������
};
struct RIGHT_EDGE
{
    int16 row;  //������
    int16 col;  //������
};
uint8 L_edge_row[countnum],L_edge_col[countnum];
uint8 R_edge_row[countnum],R_edge_col[countnum];
struct LEFT_EDGE  L_edge[countnum];     //��߽�ṹ��
struct RIGHT_EDGE R_edge[countnum];    //�ұ߽�ṹ��
uint8 L_edge_count=0, R_edge_count = 0;                  //���ұߵ�ĸ���
uint8 new_L_edge_count=0, new_R_edge_count=0;
uint8 dire_left,dire_right;                                 //��¼��һ��������λ��
uint8 turn_left,turn_right;
uint8 L_search_amount = countnum, R_search_amount = countnum;  //���ұ߽��ѵ�ʱ��������ĵ�

const int dir_front[4][2] = {{0,  -1},
                             {1,  0},
                             {0,  1},
                             {-1, 0}};
const int dir_frontleft[4][2] = {{-1, -1},
                                {1,  -1},
                                {1,  1},
                                {-1, 1}};
const int dir_frontright[4][2] = {{1,  -1},
                                 {1,  1},
                                 {-1, 1},
                                 {-1, -1}};
#define clip_value (7)
void search_neighborhood(void)
{
    L_edge_count = 0;//��ߵ������0
    R_edge_count = 0;//�ұߵ������0
    new_L_edge_count=0;
    new_R_edge_count=0;
    uint8 zx_flag[MT9V03X_H]={0};
    uint8 yx_flag[MT9V03X_H]={0};
    //��������
    uint8 new_row=0;
    uint8 new_col=0;
    uint8 cnt_left;
    uint8 cnt_right;
    L_edge[0].row = L_start_y;
    L_edge[0].col = L_start_x;
    L_edge_count+=1;
    int16 curr_row = L_start_y;//��ʼ��������
    int16 curr_col = L_start_x;//��ʼ��������
    zx[curr_row]=curr_col;
    zx_flag[curr_row]=1;
    dire_left = 0; //��ʼ���ϸ��߽�������
    turn_left = 0;//ת����� ��ֹ��ѭ��
    //��ʼ���ߣ����ȡ150���㣬���������ѣ���7����λ
    while(L_edge_count < L_search_amount)    //�������150����
    {
        if(turn_left>=4) break;
        int local_thres = 0;
        for(int dy = -1; dy <= 1; dy++)
        {
            for(int dx = -1; dx <= 1; dx++)
            {
                local_thres += mt9v03x_image[curr_row + dy][curr_col + dx];
            }
        }
        local_thres /= 9;
        local_thres -= clip_value;
        int front_value = mt9v03x_image[ curr_row + dir_front[dire_left][1] ][ curr_col + dir_front[dire_left][0] ];
        int frontleft_value = mt9v03x_image[ curr_row + dir_frontleft[dire_left][1] ][ curr_col +  dir_frontleft[dire_left][0] ];
        //���߹���
        if(front_value<local_thres)   //�Ϻ�
        {
            dire_left = (dire_left+1)%4;
            turn_left++;
        }
        else if(frontleft_value<local_thres)    //���Ϻ�
        {
            curr_row = curr_row + dir_front[dire_left][1];
            curr_col = curr_col + dir_front[dire_left][0];
            ////Խ���˳� ��Խ�����Խ�磨���������������ң�
            if(curr_row <1||curr_row>MT9V03X_H-2||curr_col<1||curr_col>MT9V03X_W-2||curr_row <= Finnalline+1)  break;
            L_edge[L_edge_count].row = curr_row;
            L_edge[L_edge_count].col = curr_col;
            L_edge_count = L_edge_count + 1;
            turn_left = 0;
        }
        else                  //�ϰ� ���ϰ�
        {
            curr_row = curr_row + dir_frontleft[dire_left][1];
            curr_col = curr_col + dir_frontleft[dire_left][0];
            dire_left = (dire_left + 3) % 4;
            ////Խ���˳� ��Խ�����Խ�磨���������������ң�
            if(curr_row <1||curr_row>MT9V03X_H-2||curr_col<1||curr_col>MT9V03X_W-2||curr_row <= Finnalline+1)  break;
            L_edge[L_edge_count].row = curr_row;
            L_edge[L_edge_count].col = curr_col;
            L_edge_count = L_edge_count + 1;
            turn_left = 0;
        }
        ////////��������ı߽�
        if(zx_flag[curr_row]!=1)
        {
            zx[curr_row]=curr_col;
            zx_flag[curr_row]=1;
        }
    }
    get_turningleft_point();//����յ�
    if( (L_corner_flag==1&&mt9v03x_image[L_corner_row][L_corner_col+1]>Threshold)||(Cross_Flag==1&&mt9v03x_image[MT9V03X_H-2][20]>Threshold) )//������
    {
        if(L_corner_flag==1)
        {
            for(int i=L_corner_row;i>0;i--)
            {
                if(mt9v03x_image[i-1][L_corner_col+1]<=Threshold)
                {
                    new_row=i;
                    break;
                }
            }
            new_col=L_corner_col+1;
        }
        else if(Cross_Flag==1)
        {
            for(int i=MT9V03X_H-2;i>0;i--)
            {
                if(mt9v03x_image[i-1][20]<=Threshold)
                {
                    new_row=i;
                    break;
                }
            }
            new_col=20;
        }
        if(new_row>15)//ȷ��������ȷ
        {
            new_L_edge_count=L_edge_count;//��¼�´�ʱ������ʼ�߽���
            curr_row=new_row;curr_col=new_col;
            L_edge[L_edge_count].row = new_row;
            L_edge[L_edge_count].col = new_col;
            zx[curr_row]=curr_col;
            zx_flag[curr_row]=2;
            dire_left = 0; //��ʼ���ϸ��߽�������
            turn_left = 0;//ת����� ��ֹ��ѭ��
            cnt_left = L_edge_count;
            while(L_edge_count < L_search_amount)
            {
//                if(curr_row==new_row&&curr_col==new_col&&cnt_left<L_edge_count) break;
                if(turn_left>=4) break;
                int local_thres = 0;
                for(int dy = -1; dy <= 1; dy++)
                {
                    for(int dx = -1; dx <= 1; dx++)
                    {
                        local_thres += mt9v03x_image[curr_row + dy][curr_col + dx];
                    }
                }
                local_thres /= 9;
                local_thres -= clip_value;
                int front_value = mt9v03x_image[ curr_row + dir_front[dire_left][1] ][ curr_col + dir_front[dire_left][0] ];
                int frontleft_value = mt9v03x_image[ curr_row + dir_frontleft[dire_left][1] ][ curr_col +  dir_frontleft[dire_left][0] ];
                //���߹���
                if(front_value<local_thres)   //�Ϻ�
                {
                    dire_left = (dire_left+1)%4;
                    turn_left++;
                }
                else if(frontleft_value<local_thres)    //���Ϻ�
                {
                    curr_row = curr_row + dir_front[dire_left][1];
                    curr_col = curr_col + dir_front[dire_left][0];
                    ////Խ���˳� ��Խ�����Խ�磨���������������ң�
                    if(curr_row <1||curr_row>MT9V03X_H-2||curr_col<1||curr_col>MT9V03X_W-2||curr_row <= Finnalline+1)  break;
                    L_edge[L_edge_count].row = curr_row;
                    L_edge[L_edge_count].col = curr_col;
                    L_edge_count = L_edge_count + 1;
                    turn_left = 0;
                }
                else                  //�ϰ� ���ϰ�
                {
                    curr_row = curr_row + dir_frontleft[dire_left][1];
                    curr_col = curr_col + dir_frontleft[dire_left][0];
                    dire_left = (dire_left + 3) % 4;
                    ////Խ���˳� ��Խ�����Խ�磨���������������ң�
                    if(curr_row <1||curr_row>MT9V03X_H-2||curr_col<1||curr_col>MT9V03X_W-2||curr_row <= Finnalline+1)  break;
                    L_edge[L_edge_count].row = curr_row;
                    L_edge[L_edge_count].col = curr_col;
                    L_edge_count = L_edge_count + 1;
                    turn_left = 0;
                }
                ////////��������ı߽�
                if(zx_flag[curr_row]!=2)
                {
                    zx[curr_row]=curr_col;
                    zx_flag[curr_row]=2;
                }
            }
        }
    }
     R_edge[0].row = R_start_y;
     R_edge[0].col = R_start_x;
     R_edge_count+=1;
     curr_row = R_start_y;
     curr_col = R_start_x;
     yx[curr_row]=curr_col;
     yx_flag[curr_row]=1;
     dire_right = 0;
     turn_right = 0;
     while(R_edge_count < R_search_amount)
     {
         if(turn_right>=4) break;
         int local_thres = 0;
         for(int dy = -1; dy <= 1; dy++)
         {
             for(int dx = -1; dx <= 1; dx++)
             {
                 local_thres += mt9v03x_image[curr_row + dy][curr_col + dx];
             }
         }
         local_thres /= 9;
         local_thres -= clip_value;
         int front_value = mt9v03x_image[ curr_row + dir_front[dire_right][1] ][ curr_col + dir_front[dire_right][0] ];
         int frontright_value = mt9v03x_image[ curr_row + dir_frontright[dire_right][1] ][ curr_col +  dir_frontright[dire_right][0] ];
         //���߹���
         if(front_value<local_thres)   //�Ϻ�
         {
             dire_right = (dire_right+3)%4;
             turn_right++;
         }
         else if(frontright_value<local_thres)    //���Ϻ�
         {
             curr_row = curr_row + dir_front[dire_right][1];
             curr_col = curr_col + dir_front[dire_right][0];
             ////Խ���˳� ��Խ�����Խ�磨���������������ң�
             if(curr_row <1||curr_row>MT9V03X_H-2||curr_col<1||curr_col>MT9V03X_W-2||curr_row <= Finnalline+1)  break;
             R_edge[R_edge_count].row = curr_row;
             R_edge[R_edge_count].col = curr_col;
             R_edge_count = R_edge_count + 1;
             turn_right = 0;
         }
         else                  //�ϰ� ���ϰ�
         {
             curr_row = curr_row + dir_frontright[dire_right][1];
             curr_col = curr_col + dir_frontright[dire_right][0];
             dire_right = (dire_right + 1) % 4;
             ////Խ���˳� ��Խ�����Խ�磨���������������ң�
             if(curr_row <1||curr_row>MT9V03X_H-2||curr_col<1||curr_col>MT9V03X_W-2||curr_row <= Finnalline+1)  break;
             R_edge[R_edge_count].row = curr_row;
             R_edge[R_edge_count].col = curr_col;
             R_edge_count = R_edge_count + 1;
             turn_right = 0;
         }
         if(yx_flag[curr_row]!=1)
         {
             yx[curr_row]=curr_col;
             yx_flag[curr_row]=1;
         }
     }
         get_turningright_point();//���ҹյ�
         if((R_corner_flag==1&&mt9v03x_image[R_corner_row][R_corner_col-1]>Threshold) || (Cross_Flag==1&&mt9v03x_image[MT9V03X_H-2][MT9V03X_W-20]>Threshold))
         {
             if(R_corner_flag==1)
             {
                 for(int i=R_corner_row;i>0;i--)
                 {
                     if(mt9v03x_image[i-1][R_corner_col-1]<=Threshold)
                     {
                         new_row=i;
                         break;
                     }
                 }
                 new_col=R_corner_col-1;
             }
             else if(Cross_Flag==1)
             {
                 for(int i=MT9V03X_H-2;i>0;i--)
                 {
                     if(mt9v03x_image[i-1][MT9V03X_W-20]<=Threshold)
                     {
                         new_row=i;
                         break;
                     }
                 }
                 new_col=MT9V03X_W-20;
             }
             if(new_row>15)//ȷ��������ȷ
             {
                 new_R_edge_count=R_edge_count;//��¼�´�ʱ������ʼ�߽���
                 curr_row=new_row;curr_col=new_col;
                 R_edge[R_edge_count].row = new_row;
                 R_edge[R_edge_count].col = new_col;
                 yx[curr_row]=curr_col;
                 yx_flag[curr_row]=2;
                 dire_right = 0; //��ʼ���ϸ��߽�������
                 turn_right = 0;//ת����� ��ֹ��ѭ��
                 cnt_right = R_edge_count;
                 while(R_edge_count < R_search_amount)
                 {
                     ////Խ���˳� ��Խ�����Խ�磨���������������ң�
//                     if(curr_row==new_row&&curr_col==new_col&&cnt_right<R_edge_count) break;
                     if(turn_right>=4) break;
                     int local_thres = 0;
                     for(int dy = -1; dy <= 1; dy++)
                     {
                         for(int dx = -1; dx <= 1; dx++)
                         {
                             local_thres += mt9v03x_image[curr_row + dy][curr_col + dx];
                         }
                     }
                     local_thres /= 9;
                     local_thres -= clip_value;
                     int front_value = mt9v03x_image[ curr_row + dir_front[dire_right][1] ][ curr_col + dir_front[dire_right][0] ];
                     int frontright_value = mt9v03x_image[ curr_row + dir_frontright[dire_right][1] ][ curr_col +  dir_frontright[dire_right][0] ];
                     //���߹���
                     if(front_value<local_thres)   //�Ϻ�
                     {
                         dire_right = (dire_right+3)%4;
                         turn_right++;
                     }
                     else if(frontright_value<local_thres)    //���Ϻ�
                     {
                         curr_row = curr_row + dir_front[dire_right][1];
                         curr_col = curr_col + dir_front[dire_right][0];
                         if(curr_row <1||curr_row>MT9V03X_H-2||curr_col<1||curr_col>MT9V03X_W-2||curr_row <= Finnalline+1)  break;
                         R_edge[R_edge_count].row = curr_row;
                         R_edge[R_edge_count].col = curr_col;
                         R_edge_count = R_edge_count + 1;
                         turn_right = 0;
                     }
                     else                  //�ϰ� ���ϰ�
                     {
                         curr_row = curr_row + dir_frontright[dire_right][1];
                         curr_col = curr_col + dir_frontright[dire_right][0];
                         dire_right = (dire_right + 1) % 4;
                         if(curr_row <1||curr_row>MT9V03X_H-2||curr_col<1||curr_col>MT9V03X_W-2||curr_row <= Finnalline+1)  break;
                         R_edge[R_edge_count].row = curr_row;
                         R_edge[R_edge_count].col = curr_col;
                         R_edge_count = R_edge_count + 1;
                         turn_right = 0;
                     }
                     if(yx_flag[curr_row]!=2)
                     {
                         yx[curr_row]=curr_col;
                         yx_flag[curr_row]=2;
                     }
                 }
             }
         }
//         for(int i = 0;i<countnum;i++)
//         {
//             L_edge_row[i]=L_edge[i].row;
//             L_edge_col[i]=L_edge[i].col;
//
//             R_edge_row[i]=R_edge[i].row;
//             R_edge_col[i]=R_edge[i].col;
//
//         }��ͼ��
}

/*---------------------------------------------------------------
 ����    ����search_neighborhood ��ֵ����ֵ��
 ����    �ܡ��Թ����ұ߽�
 ����    ������
 ���� �� ֵ����
 ��ע�����
 ----------------------------------------------------------------*/
void search_neighborhood_zeroone(void)
{
    L_edge_count = 0;//��ߵ������0
    R_edge_count = 0;//�ұߵ������0
    new_L_edge_count=0;
    new_R_edge_count=0;
    uint8 zx_flag[MT9V03X_H]={0};
    uint8 yx_flag[MT9V03X_H]={0};
    //��������
    uint8 new_row=0;
    uint8 new_col=0;
    uint8 cnt_left;
    uint8 cnt_right;
    L_edge[0].row = L_start_y;
    L_edge[0].col = L_start_x;
    L_edge_count+=1;
    int16 curr_row = L_start_y;//��ʼ��������
    int16 curr_col = L_start_x;//��ʼ��������
    zx[curr_row]=curr_col;
    zx_flag[curr_row]=1;
    dire_left = 0; //��ʼ���ϸ��߽�������
    turn_left = 0;//ת����� ��ֹ��ѭ��
    //��ʼ���ߣ����ȡ150���㣬���������ѣ���7����λ
    while(L_edge_count < L_search_amount)    //�������150����
    {
        if(turn_left>=4) break;
        int front_value = image[ curr_row + dir_front[dire_left][1] ][ curr_col + dir_front[dire_left][0] ];
        int frontleft_value = image[ curr_row + dir_frontleft[dire_left][1] ][ curr_col +  dir_frontleft[dire_left][0] ];
        //���߹���
        if(front_value==0)   //�Ϻ�
        {
            dire_left = (dire_left+1)%4;
            turn_left++;
        }
        else if(frontleft_value==0)    //���Ϻ�
        {
            curr_row = curr_row + dir_front[dire_left][1];
            curr_col = curr_col + dir_front[dire_left][0];
            ////Խ���˳� ��Խ�����Խ�磨���������������ң�
            if(curr_row <1||curr_row>MT9V03X_H-2||curr_col<1||curr_col>MT9V03X_W-2||curr_row <= Finnalline+1)  break;
            L_edge[L_edge_count].row = curr_row;
            L_edge[L_edge_count].col = curr_col;
            L_edge_count = L_edge_count + 1;
            turn_left = 0;
        }
        else                  //�ϰ� ���ϰ�
        {
            curr_row = curr_row + dir_frontleft[dire_left][1];
            curr_col = curr_col + dir_frontleft[dire_left][0];
            dire_left = (dire_left + 3) % 4;
            ////Խ���˳� ��Խ�����Խ�磨���������������ң�
            if(curr_row <1||curr_row>MT9V03X_H-2||curr_col<1||curr_col>MT9V03X_W-2||curr_row <= Finnalline+1)  break;
            L_edge[L_edge_count].row = curr_row;
            L_edge[L_edge_count].col = curr_col;
            L_edge_count = L_edge_count + 1;
            turn_left = 0;
        }
        ////////��������ı߽�
        if(zx_flag[curr_row]!=1)
        {
            zx[curr_row]=curr_col;
            zx_flag[curr_row]=1;
        }
    }
    get_turningleft_point();//����յ�
    if( (L_corner_flag==1&&image[L_corner_row][L_corner_col+1]==255)||(Cross_Flag==1&&image[MT9V03X_H-2][20]==255) )//������
    {
        if(L_corner_flag==1)
        {
            for(int i=L_corner_row;i>0;i--)
            {
                if(image[i-1][L_corner_col+5]==0)
                {
                    new_row=i;
                    new_col=L_corner_col+5;
                    break;
                }
            }
//            if(new_row<=40)
//            {
//                for(int i=L_corner_row;i>0;i--)
//                {
//                    if(image[i-1][L_corner_col+15]==0)
//                    {
//                        new_row=i;
//                        new_col=L_corner_col+15;
//                        break;
//                    }
//                }
//            }
        }
        else if(Cross_Flag==1)
        {
            for(int i=MT9V03X_H-5;i>0;i--)
            {
                if(image[i-1][40]==0)
                {
                    new_row=i;
                    new_col=40;
                    break;
                }
            }
//            if(new_row<=40)
//            {
//                for(int i=MT9V03X_H-5;i>0;i--)
//                {
//                    if(image[i-1][60]==0)
//                    {
//                        new_row=i;
//                        new_col=60;
//                        break;
//                    }
//                }
//            }
        }
        if(new_row>15)//ȷ��������ȷ
        {
            new_L_edge_count=L_edge_count;//��¼�´�ʱ������ʼ�߽���
            curr_row=new_row;curr_col=new_col;
            L_edge[L_edge_count].row = new_row;
            L_edge[L_edge_count].col = new_col;
            zx[curr_row]=curr_col;
            zx_flag[curr_row]=2;
            dire_left = 0; //��ʼ���ϸ��߽�������
            turn_left = 0;//ת����� ��ֹ��ѭ��
            cnt_left = L_edge_count;
            while(L_edge_count < L_search_amount)
            {
//                if(curr_row==new_row&&curr_col==new_col&&cnt_left<L_edge_count) break;
                if(turn_left>=4) break;
                int front_value = image[ curr_row + dir_front[dire_left][1] ][ curr_col + dir_front[dire_left][0] ];
                int frontleft_value = image[ curr_row + dir_frontleft[dire_left][1] ][ curr_col +  dir_frontleft[dire_left][0] ];
                //���߹���
                if(front_value==0)   //�Ϻ�
                {
                    dire_left = (dire_left+1)%4;
                    turn_left++;
                }
                else if(frontleft_value==0)    //���Ϻ�
                {
                    curr_row = curr_row + dir_front[dire_left][1];
                    curr_col = curr_col + dir_front[dire_left][0];
                    ////Խ���˳� ��Խ�����Խ�磨���������������ң�
                    if(curr_row <1||curr_row>MT9V03X_H-2||curr_col<1||curr_col>MT9V03X_W-2||curr_row <= Finnalline+1)  break;
                    L_edge[L_edge_count].row = curr_row;
                    L_edge[L_edge_count].col = curr_col;
                    L_edge_count = L_edge_count + 1;
                    turn_left = 0;
                }
                else                  //�ϰ� ���ϰ�
                {
                    curr_row = curr_row + dir_frontleft[dire_left][1];
                    curr_col = curr_col + dir_frontleft[dire_left][0];
                    dire_left = (dire_left + 3) % 4;
                    ////Խ���˳� ��Խ�����Խ�磨���������������ң�
                    if(curr_row <1||curr_row>MT9V03X_H-2||curr_col<1||curr_col>MT9V03X_W-2||curr_row <= Finnalline+1)  break;
                    L_edge[L_edge_count].row = curr_row;
                    L_edge[L_edge_count].col = curr_col;
                    L_edge_count = L_edge_count + 1;
                    turn_left = 0;
                }
                ////////��������ı߽�
                if(zx_flag[curr_row]!=2)
                {
                    zx[curr_row]=curr_col;
                    zx_flag[curr_row]=2;
                }
            }
        }
    }
     R_edge[0].row = R_start_y;
     R_edge[0].col = R_start_x;
     R_edge_count+=1;
     curr_row = R_start_y;
     curr_col = R_start_x;
     yx[curr_row]=curr_col;
     yx_flag[curr_row]=1;
     dire_right = 0;
     turn_right = 0;
     while(R_edge_count < R_search_amount)
     {
         if(turn_right>=4) break;
         int front_value = image[ curr_row + dir_front[dire_right][1] ][ curr_col + dir_front[dire_right][0] ];
         int frontright_value = image[ curr_row + dir_frontright[dire_right][1] ][ curr_col +  dir_frontright[dire_right][0] ];
         //���߹���
         if(front_value==0)   //�Ϻ�
         {
             dire_right = (dire_right+3)%4;
             turn_right++;
         }
         else if(frontright_value==0)    //���Ϻ�
         {
             curr_row = curr_row + dir_front[dire_right][1];
             curr_col = curr_col + dir_front[dire_right][0];
             ////Խ���˳� ��Խ�����Խ�磨���������������ң�
             if(curr_row <1||curr_row>MT9V03X_H-2||curr_col<1||curr_col>MT9V03X_W-2||curr_row <= Finnalline+1)  break;
             R_edge[R_edge_count].row = curr_row;
             R_edge[R_edge_count].col = curr_col;
             R_edge_count = R_edge_count + 1;
             turn_right = 0;
         }
         else                  //�ϰ� ���ϰ�
         {
             curr_row = curr_row + dir_frontright[dire_right][1];
             curr_col = curr_col + dir_frontright[dire_right][0];
             dire_right = (dire_right + 1) % 4;
             ////Խ���˳� ��Խ�����Խ�磨���������������ң�
             if(curr_row <1||curr_row>MT9V03X_H-2||curr_col<1||curr_col>MT9V03X_W-2||curr_row <= Finnalline+1)  break;
             R_edge[R_edge_count].row = curr_row;
             R_edge[R_edge_count].col = curr_col;
             R_edge_count = R_edge_count + 1;
             turn_right = 0;
         }
         if(yx_flag[curr_row]!=1)
         {
             yx[curr_row]=curr_col;
             yx_flag[curr_row]=1;
         }
     }
         get_turningright_point();//���ҹյ�
         if((R_corner_flag==1&&image[R_corner_row][R_corner_col-1]==255) || (Cross_Flag==1&&image[MT9V03X_H-2][MT9V03X_W-20]==255))
         {
             if(R_corner_flag==1)
             {
                 for(int i=R_corner_row;i>0;i--)
                 {
                     if(image[i-1][R_corner_col-5]==0)
                     {
                         new_row=i;
                         new_col=R_corner_col-5;
                         break;
                     }
                 }
//                 if(new_row<=40)
//                 {
//                     for(int i=R_corner_row;i>0;i--)
//                     {
//                         if(image[i-1][R_corner_col-15]==0)
//                         {
//                             new_row=i;
//                             new_col=R_corner_col-15;
//                             break;
//                         }
//                     }
//                 }
             }
             else if(Cross_Flag==1)
             {
                 for(int i=MT9V03X_H-5;i>0;i--)
                 {
                     if(image[i-1][MT9V03X_W-40]==0)
                     {
                         new_row=i;
                         new_col=MT9V03X_W-40;
                         break;
                     }
                 }
//                 if(new_row<=40)
//                 {
//                     for(int i=MT9V03X_H-5;i>0;i--)
//                     {
//                         if(image[i-1][MT9V03X_W-60]==0)
//                         {
//                             new_row=i;
//                             new_col=MT9V03X_W-60;
//                             break;
//                         }
//                     }
//                 }
             }
             if(new_row>15)//ȷ��������ȷ
             {
                 new_R_edge_count=R_edge_count;//��¼�´�ʱ������ʼ�߽���
                 curr_row=new_row;curr_col=new_col;
                 R_edge[R_edge_count].row = new_row;
                 R_edge[R_edge_count].col = new_col;
                 yx[curr_row]=curr_col;
                 yx_flag[curr_row]=2;
                 dire_right = 0; //��ʼ���ϸ��߽�������
                 turn_right = 0;//ת����� ��ֹ��ѭ��
                 cnt_right = R_edge_count;
                 while(R_edge_count < R_search_amount)
                 {
                     ////Խ���˳� ��Խ�����Խ�磨���������������ң�
//                     if(curr_row==new_row&&curr_col==new_col&&cnt_right<R_edge_count) break;
                     if(turn_right>=4) break;
                     int front_value = image[ curr_row + dir_front[dire_right][1] ][ curr_col + dir_front[dire_right][0] ];
                     int frontright_value = image[ curr_row + dir_frontright[dire_right][1] ][ curr_col +  dir_frontright[dire_right][0] ];
                     //���߹���
                     if(front_value==0)   //�Ϻ�
                     {
                         dire_right = (dire_right+3)%4;
                         turn_right++;
                     }
                     else if(frontright_value==0)    //���Ϻ�
                     {
                         curr_row = curr_row + dir_front[dire_right][1];
                         curr_col = curr_col + dir_front[dire_right][0];
                         if(curr_row <1||curr_row>MT9V03X_H-2||curr_col<1||curr_col>MT9V03X_W-2||curr_row <= Finnalline+1)  break;
                         R_edge[R_edge_count].row = curr_row;
                         R_edge[R_edge_count].col = curr_col;
                         R_edge_count = R_edge_count + 1;
                         turn_right = 0;
                     }
                     else                  //�ϰ� ���ϰ�
                     {
                         curr_row = curr_row + dir_frontright[dire_right][1];
                         curr_col = curr_col + dir_frontright[dire_right][0];
                         dire_right = (dire_right + 1) % 4;
                         if(curr_row <1||curr_row>MT9V03X_H-2||curr_col<1||curr_col>MT9V03X_W-2||curr_row <= Finnalline+1)  break;
                         R_edge[R_edge_count].row = curr_row;
                         R_edge[R_edge_count].col = curr_col;
                         R_edge_count = R_edge_count + 1;
                         turn_right = 0;
                     }
                     if(yx_flag[curr_row]!=2)
                     {
                         yx[curr_row]=curr_col;
                         yx_flag[curr_row]=2;
                     }
                 }
             }
         }
//         for(int i = 0;i<countnum;i++)
//         {
//             L_edge_row[i]=L_edge[i].row;
//             L_edge_col[i]=L_edge[i].col;
//
//             R_edge_row[i]=R_edge[i].row;
//             R_edge_col[i]=R_edge[i].col;
//
//         }��ͼ��
}

/*---------------------------------------------------------------
 ����    ����clear_find_point
 ����    �ܡ�������߽��ʼ��
 ����    ������
 ���� �� ֵ��
 ��ע�����
 ----------------------------------------------------------------*/
void clear_find_point(void)
{
    for(int i = 0;i<countnum;i++)
    {
        L_edge[i].row = 0;
        L_edge[i].col = 0;
        R_edge[i].row = 0;
        R_edge[i].col = MT9V03X_W-1;
    }
}


int16 L_corner_flag = 0;//��յ���ڱ�־
int16 L_corner_row = 0;//��յ�������
int16 L_corner_col = 0;//��յ�������
float L_corner_angle = 0;//��յ�Ƕ�
int16 R_corner_flag = 0;//�ҹյ���ڱ�־
int16 R_corner_row = 0;//�ҹյ�������
int16 R_corner_col = 0;//�ҹյ�������
float R_corner_angle = 0;//�ҹյ�Ƕ�
uint8 enable_L_corner=1,enable_R_corner=1;
//Բ���յ��־λ
int16 L_circle_corner_flag = 0;//��յ���ڱ�־
int16 L_circle_corner_row = 0;//��յ�������
int16 L_circle_corner_col = 0;//��յ�������
int16 R_circle_corner_flag = 0;//�ҹյ���ڱ�־
int16 R_circle_corner_row = 0;//�ҹյ�������
int16 R_circle_corner_col = 0;//�ҹյ�������
/*---------------------------------------------------------------
 ����    ����get_turningleft_point
 ����    �ܡ����¹յ���
 ����    ������
 ���� �� ֵ��
 ��ע�����
 ----------------------------------------------------------------*/
void get_turningleft_point(void)
{
    L_corner_flag = 0;// ��ʼ������
    L_corner_row = 0;
    L_corner_col = 0;
    L_corner_angle = 0;
    L_circle_corner_flag = 0;
    L_circle_corner_row = 0;
    L_circle_corner_col = 0;
    if(enable_L_corner) //���ʹ��������յ�
    {
        if(L_edge_count > 9)
        {
            for(int i = 0; i<L_edge_count-9;i++)
            {
                if(L_edge[i+8].row>5)
                {
                    if((L_edge[i].col - L_edge[i + 4].col) * (L_edge[i + 8].col - L_edge[i + 4].col) +
                       (L_edge[i].row - L_edge[i + 4].row) * (L_edge[i + 8].row - L_edge[i + 4].row) >= 0) //����ȷ��Ϊ��ǻ���ֱ�� ������
                    {
                        if(L_edge[i+4].col>L_edge[i+8].col)
                        {
                            L_corner_flag = 1;
                            L_corner_row = L_edge[i+4].row;
                            L_corner_col = L_edge[i+4].col;
                            break;
                        }
                    }
                }
            }
        }
    }
}
/*---------------------------------------------------------------
 ����    ����get_turningright_point
 ����    �ܡ����¹յ���
 ����    ������
 ���� �� ֵ��
 ��ע�����
 ----------------------------------------------------------------*/
void get_turningright_point(void)
{
    R_corner_flag = 0;//��ʼ������
    R_corner_row = 0;
    R_corner_col = 0;
    R_corner_angle = 0;
    R_circle_corner_flag = 0;
    R_circle_corner_row = 0;
    R_circle_corner_col = 0;
    if(enable_R_corner)    //���ʹ�������ҹյ�
    {
        if(R_edge_count > 9)
        {
            for(int i = 0; i<R_edge_count-9;i++)
            {
                if(R_edge[i+8].row>5)
                {
                    if((R_edge[i].col - R_edge[i + 4].col) * (R_edge[i + 8].col - R_edge[i + 4].col) +
                    (R_edge[i].row - R_edge[i + 4].row) * (R_edge[i + 8].row - R_edge[i + 4].row) >= 0) //����ȷ��Ϊ��ǻ���ֱ�� ������
                    {
                        R_corner_flag = 1;
                        R_corner_row = R_edge[i+4].row;
                        R_corner_col = R_edge[i+4].col;
                        break;
                    }
                }
            }
        }
    }
}

int16 L_upcorner_flag = 0;//��յ���ڱ�־
int16 L_upcorner_row = 0;//��յ�������
int16 L_upcorner_col = 0;//��յ�������
int L_upcorner_angle = 0;//��յ�Ƕ�
int16 R_upcorner_flag = 0;//�ҹյ���ڱ�־
int16 R_upcorner_row = 0;//�ҹյ�������
int16 R_upcorner_col = 0;//�ҹյ�������
int R_upcorner_angle = 0;//�ҹյ�Ƕ�
uint8 enable_L_upcorner=1,enable_R_upcorner=1;
int serchendline;
/*---------------------------------------------------------------
 ����    ����get_upturningleft_point
 ����    �ܡ����Ϲյ���
 ����    ������
 ���� �� ֵ��
 ��ע�����
 ----------------------------------------------------------------*/
void get_upturningleft_point(void)
{
    L_upcorner_flag = 0;// ��ʼ������
    L_upcorner_row = 0;
    L_upcorner_col = 0;
    L_upcorner_angle = 0;
    if(enable_L_upcorner) //���ʹ��������յ�
    {
//        if( (L_edge_count-new_L_edge_count) > 9)
//        {
//            for(int i = new_L_edge_count; i<L_edge_count-9;i++)
//            {
//                if(L_edge[i+8].row>5)
//                {
//                    if((L_edge[i].col - L_edge[i + 4].col) * (L_edge[i + 8].col - L_edge[i + 4].col) +
//                       (L_edge[i].row - L_edge[i + 4].row) * (L_edge[i + 8].row - L_edge[i + 4].row) < 0) //����ȷ��Ϊ�۽�
//                    {
//                        if(L_edge[i+4].col<L_edge[i+8].col)
//                        {
//                            L_upcorner_flag = 1;
//                            L_upcorner_row = L_edge[i+4].row;
//                            L_upcorner_col = L_edge[i+4].col;
//                            break;
//                        }
//                    }
//                }
//            }
//        }
//        if(L_corner_flag==1)
//        {
//            if(Finnalline>=3)  serchendline = Finnalline;
//            else  serchendline = 3;
//            for(int i=L_corner_row-3;i>serchendline;i--)
//            {
//                if(
//                   abs(zx[i]-zx[i-1])<=5&&//�ǵ����ֵ���Ը���
//                   abs(zx[i-1]-zx[i-2])<=5&&
//                   abs(zx[i-2]-zx[i-3])<=5&&
//                      (zx[i]-zx[i+1])>=5&&
//                      (zx[i]-zx[i+2])>=5&&
//                      (zx[i]-zx[i+3])>=10&&zx[i]<MT9V03X_W-30&&zx[i]>30&&zx[i]>=L_corner_col+5)
//                {
//                    if(i>40)
//                    {
//                        L_upcorner_flag = 1;
//                        L_upcorner_row = i;
//                        L_upcorner_col = zx[i];
//                        break;
//                    }
//                }
//            }
//        }
//        else
//        {
            for(int i=MT9V03X_H-1-3;i>Finnalline;i--)
            {
                if(
                   abs(zx[i]-zx[i-1])<=5&&//�ǵ����ֵ���Ը���
                   abs(zx[i-1]-zx[i-2])<=5&&
                   abs(zx[i-2]-zx[i-3])<=5&&
                      (zx[i]-zx[i+1])>=5&&
                      (zx[i]-zx[i+2])>=8&&
                      (zx[i]-zx[i+3])>=10&&zx[i]<MT9V03X_W-30&&zx[i]>30)
                {
                    if(i>30)
                    {
                        L_upcorner_flag = 1;
                        L_upcorner_row = i;
                        L_upcorner_col = zx[i];
                        break;
                    }
                }
            }
//        }
    }
}

/*---------------------------------------------------------------
 ����    ����get_upturningright_point
 ����    �ܡ����Ϲյ���
 ����    ������
 ���� �� ֵ��
 ��ע�����
 ----------------------------------------------------------------*/
void get_upturningright_point(void)
{
    R_upcorner_flag = 0;//��ʼ������
    R_upcorner_row = 0;
    R_upcorner_col = 0;
    R_upcorner_angle = 0;
    if(enable_R_corner)    //���ʹ�������ҹյ�
    {
//        if(R_edge_count > 9)
//        {
//            for(int i = 0; i<R_edge_count-9;i++)
//            {
//                if(R_edge[i+8].row>5)
//                {
//                    if((R_edge[i].col - R_edge[i + 4].col) * (R_edge[i + 8].col - R_edge[i + 4].col) +
//                    (R_edge[i].row - R_edge[i + 4].row) * (R_edge[i + 8].row - R_edge[i + 4].row) >= 0) //����ȷ��Ϊ��ǻ���ֱ�� ������
//                    {
//                        if(R_edge[i+8].col>R_edge[i+4].col&&i<50)
//                        {
//                            R_corner_flag = 1;
//                            R_corner_row = R_edge[i+4].row;
//                            R_corner_col = R_edge[i+4].col;
//                            break;
//                        }
//                    }
//                }
//            }
//            if(R_corner_flag==1)
//            {
//                if(Finnalline>=3)  serchendline = Finnalline;
//                else  serchendline = 3;
//                for(int i=R_corner_row-3;i>serchendline;i--)
//                {
//                    if(
//                       abs(yx[i-1]-yx[i])<=5&&//�ǵ����ֵ���Ը���
//                       abs(yx[i-2]-yx[i-1])<=5&&
//                       abs(yx[i-3]-yx[i-2])<=5&&
//                          (yx[i+1]-yx[i])>=5&&
//                          (yx[i+2]-yx[i])>=5&&
//                          (yx[i+3]-yx[i])>=10&&yx[i]>30&&yx[i]<MT9V03X_W-30&&yx[i]<=R_corner_col-5)
//                    {
//                        if(i>40)
//                        {
//                            R_upcorner_flag = 1;
//                            R_upcorner_row = i;
//                            R_upcorner_col = yx[i];
//                            break;
//                        }
//                    }
//                }
//            }
//            else
//            {
                for(int i=MT9V03X_H-1-3;i>Finnalline;i--)
                {
                    if(
                       abs(yx[i-1]-yx[i])<=5&&//�ǵ����ֵ���Ը���
                       abs(yx[i-2]-yx[i-1])<=5&&
                       abs(yx[i-3]-yx[i-2])<=5&&
                          (yx[i+1]-yx[i])>=5&&
                          (yx[i+2]-yx[i])>=8&&
                          (yx[i+3]-yx[i])>=10&&yx[i]>30&&yx[i]<MT9V03X_W-30)
                    {
                        if(i>30)
                        {
                            R_upcorner_flag = 1;
                            R_upcorner_row = i;
                            R_upcorner_col = yx[i];
                            break;
                        }
                    }
                }
//            }
        }
}



int16 Lin_circleup_flag = 0;//��յ���ڱ�־
int16 Lin_circleup_row = 0;//��յ�������
int16 Lin_circleup_col = 0;//��յ�������
/*-------------------------------------------------------------------------------------------------------------------
  @brief     ��Բ���뻷���Ϲյ�
  @param     ��ʼ�㣬��ֹ��
  @return    �����ڵ��������Ҳ�������0
  Sample     Find_left_Up_Point(int start,int end);
  @note      ǰ5��5�������С�����������ǽǵ�
-------------------------------------------------------------------------------------------------------------------*/
void Circle_in_Left()//�����Ըı䣬����ֵ�ǵ����Ըı�����ڵ�����
{
    Lin_circleup_flag = 0;// ��ʼ������
    Lin_circleup_row = 0;
    Lin_circleup_col = 0;
    if(L_edge_count > 9)
    {
        for(int i = 0; i<L_edge_count-9;i++)
        {
            if(L_edge[i].col<=L_edge[i+1].col&&L_edge[i+1].col<=L_edge[i+2].col&&
                    L_edge[i+2].col<=L_edge[i+3].col&&L_edge[i+3].col<=L_edge[i+4].col&&
                    L_edge[i+4].col<=L_edge[i+5].col&&L_edge[i+5].col<=L_edge[i+6].col&&
                    L_edge[i+6].col<=L_edge[i+7].col&&L_edge[i+7].col<=L_edge[i+8].col)
            {
                if(L_edge[i].row<=L_edge[i+1].row&&L_edge[i+1].row<=L_edge[i+2].row&&
                        L_edge[i+2].row<=L_edge[i+3].row&&L_edge[i+3].row<=L_edge[i+4].row&&
                        L_edge[i+4].row>L_edge[i+5].row&&L_edge[i+5].row>=L_edge[i+6].row&&
                        L_edge[i+6].row>=L_edge[i+7].row&&L_edge[i+7].row>=L_edge[i+8].row)//ע���м��������Ǵ��ڶ����Ǵ��ڵ���
                {
                    if(L_edge[i+4].row>40)
                    {
                        Lin_circleup_flag=1;
                        Lin_circleup_row=L_edge[i+4].row;
                        Lin_circleup_col=L_edge[i+4].col;
                        break;
                    }

                }
            }
        }
    }
}



int16 Lout_circleup_flag = 0;//��յ���ڱ�־
int16 Lout_circleup_row = 0;//��յ�������
int16 Lout_circleup_col = 0;//��յ�������
/*-------------------------------------------------------------------------------------------------------------------
  @brief     ��Բ���������Ϲյ�
  @param     ��ʼ�㣬��ֹ��
  @return    �����ڵ��������Ҳ�������0
  Sample     Find_left_Up_Point(int start,int end);
  @note      ǰ5��5�������С�����������ǽǵ�
-------------------------------------------------------------------------------------------------------------------*/
void Circle_out_Left()//�����Ըı䣬����ֵ�ǵ����Ըı�����ڵ�����
{
    Lout_circleup_flag = 0;// ��ʼ������
    Lout_circleup_row = 0;
    Lout_circleup_col = 0;
    if(R_edge_count > 9)
    {
        for(int i = 0; i<R_edge_count-9;i++)
        {
            if(R_edge[i].row>=R_edge[i+1].row&&R_edge[i+1].row>=R_edge[i+2].row&&
                    R_edge[i+2].row>=R_edge[i+3].row&&R_edge[i+3].row>=R_edge[i+4].row&&
                    R_edge[i+4].row>=R_edge[i+5].row&&R_edge[i+5].row>=R_edge[i+6].row&&
                    R_edge[i+6].row>=R_edge[i+7].row&&R_edge[i+7].row>=R_edge[i+8].row)
            {
                if(R_edge[i].col>=R_edge[i+1].col&&R_edge[i+1].col>=R_edge[i+2].col&&
                        R_edge[i+2].col>=R_edge[i+3].col&&R_edge[i+3].col>=R_edge[i+4].col&&
                        R_edge[i+4].col<R_edge[i+5].col&&R_edge[i+5].col<=R_edge[i+6].col&&
                        R_edge[i+6].col<=R_edge[i+7].col&&R_edge[i+7].col<=R_edge[i+8].col)//ע���м��������Ǵ��ڶ����Ǵ��ڵ���
                {
                    if(1)
                    {
                        Lout_circleup_flag=1;
                        Lout_circleup_row=R_edge[i+4].row;
                        Lout_circleup_col=R_edge[i+4].col;
                        break;
                    }
                }
            }
        }
    }
}

int16 Rin_circleup_flag = 0;//��յ���ڱ�־
int16 Rin_circleup_row = 0;//��յ�������
int16 Rin_circleup_col = 0;//��յ�������
/*-------------------------------------------------------------------------------------------------------------------
  @brief     ��Բ���뻷���Ϲյ�
  @param     ��ʼ�㣬��ֹ��
  @return    �����ڵ��������Ҳ�������0
  Sample     Find_left_Up_Point(int start,int end);
  @note      ǰ5��5�������С�����������ǽǵ�
-------------------------------------------------------------------------------------------------------------------*/
void Circle_in_Right()//�����Ըı䣬����ֵ�ǵ����Ըı�����ڵ�����
{
    Rin_circleup_flag = 0;// ��ʼ������
    Rin_circleup_row = 0;
    Rin_circleup_col = 0;
    if(R_edge_count > 9)
    {
        for(int i = 0; i<R_edge_count-9;i++)
        {
            if(R_edge[i].col>=R_edge[i+1].col&&R_edge[i+1].col>=R_edge[i+2].col&&
                    R_edge[i+2].col>=R_edge[i+3].col&&R_edge[i+3].col>=R_edge[i+4].col&&
                    R_edge[i+4].col>=R_edge[i+5].col&&R_edge[i+5].col>=R_edge[i+6].col&&
                    R_edge[i+6].col>=R_edge[i+7].col&&R_edge[i+7].col>=R_edge[i+8].col)
            {
                if(R_edge[i].row<=R_edge[i+1].row&&R_edge[i+1].row<=R_edge[i+2].row&&
                        R_edge[i+2].row<=R_edge[i+3].row&&R_edge[i+3].row<=R_edge[i+4].row&&
                        R_edge[i+4].row>R_edge[i+5].row&&R_edge[i+5].row>=R_edge[i+6].row&&
                        R_edge[i+6].row>=R_edge[i+7].row&&R_edge[i+7].row>=R_edge[i+8].row)//ע���м��������Ǵ��ڶ����Ǵ��ڵ���
                {
                    if(R_edge[i+4].row>40)
                    {
                        Rin_circleup_flag=1;
                        Rin_circleup_row=R_edge[i+4].row;
                        Rin_circleup_col=R_edge[i+4].col;
                        break;
                    }
                }
            }
        }
    }
}
//
int16 Rout_circleup_flag = 0;//��յ���ڱ�־
int16 Rout_circleup_row = 0;//��յ�������
int16 Rout_circleup_col = 0;//��յ�������
/*-------------------------------------------------------------------------------------------------------------------
  @brief     ��Բ���������Ϲյ�
  @param     ��ʼ�㣬��ֹ��
  @return    �����ڵ��������Ҳ�������0
  Sample     Find_left_Up_Point(int start,int end);
  @note      ǰ5��5�������С�����������ǽǵ�
-------------------------------------------------------------------------------------------------------------------*/
void Circle_out_Right()//�����Ըı䣬����ֵ�ǵ����Ըı�����ڵ�����
{
    Rout_circleup_flag = 0;// ��ʼ������
    Rout_circleup_row = 0;
    Rout_circleup_col = 0;
    if(L_edge_count > 9)
    {
        for(int i = 0; i<L_edge_count-9;i++)
        {
            if(L_edge[i].row>=L_edge[i+1].row&&L_edge[i+1].row>=L_edge[i+2].row&&
                    L_edge[i+2].row>=L_edge[i+3].row&&L_edge[i+3].row>=L_edge[i+4].row&&
                    L_edge[i+4].row>=L_edge[i+5].row&&L_edge[i+5].row>=L_edge[i+6].row&&
                    L_edge[i+6].row>=L_edge[i+7].row&&L_edge[i+7].row>=L_edge[i+8].row)
            {
                if(L_edge[i].col<=L_edge[i+1].col&&L_edge[i+1].col<=L_edge[i+2].col&&
                        L_edge[i+2].col<=L_edge[i+3].col&&L_edge[i+3].col<=L_edge[i+4].col&&
                        L_edge[i+4].col>L_edge[i+5].col&&L_edge[i+5].col>=L_edge[i+6].col&&
                        L_edge[i+6].col>=L_edge[i+7].col&&L_edge[i+7].col>=L_edge[i+8].col)//ע���м��������Ǵ��ڶ����Ǵ��ڵ���
                {
                    if(1)
                    {
                        Rout_circleup_flag=1;
                        Rout_circleup_row=L_edge[i+4].row;
                        Rout_circleup_col=L_edge[i+4].col;
                        break;
                    }
                }
            }
        }
    }
}

uint8 Threshold_boundary = 20;
/*-------------------------------------------------------------------------------------------------------------------
  @brief     ���Թ���ʼ�� �ֲ���ֵ��
  @note
-------------------------------------------------------------------------------------------------------------------*/
void fineonepoint()
{
    uint8 i,j,upward,to_left,to_right;
    uint8 L_start_flag=2,R_start_flag=2;
    uint8 h=MT9V03X_H-2;//��ʼ��
    uint8 left_findflag = 0;
    uint8 right_findflag = 0;
    Finnalline=5;

    volatile int White_Column[MT9V03X_W]={0};//ÿ�а��г���
    for (i=2;i<=MT9V03X_W-2-1;i+=2)
    {
        for (j=MT9V03X_H-2;j >= 0; j--)
        {
            if(mt9v03x_image[j][i] <= Threshold)
                break;
            else
                White_Column[i]++;
        }
    }
    //����������������
     Longest_White_Column_Left[0] =0;
     for(i=2;i<=MT9V03X_W-2-1;i+=2)
     {
         if (Longest_White_Column_Left[0] < White_Column[i])//�������һ��
         {
             Longest_White_Column_Left[0] = White_Column[i];//��0���ǰ��г���
             Longest_White_Column_Left[1] = i;              //��1�����±꣬��j��
         }
     }
     for(;h>0;h--)
     {
         if(h>=1&&mt9v03x_image[h-1][ Longest_White_Column_Left[1] ]<=Threshold)
         {
             Finnalline=h;//������
             break;
         }
     }
    for(upward=MT9V03X_H-2;upward>Finnalline;upward--)
    {
        //��߽�
        for(to_left= Longest_White_Column_Left[1]; to_left>0 ;to_left--)
        {
            if (calc_diff(mt9v03x_image[upward][to_left+5],mt9v03x_image[upward][to_left]) >= Threshold_boundary )
            {
                zx[upward]=to_left+1;
                if(L_start_flag)
                {
                    L_start_flag--;
                    if(!L_start_flag)
                    {
                        L_start_x=to_left+1;
                        L_start_y=upward;
                        left_findflag=1;
                    }
                }
                break;
            }
            else if(to_left<=1)
            {
                zx[upward]=1;
                break;
            }
        }

       //�ұ߽�
        for(to_right= Longest_White_Column_Left[1]; to_right<MT9V03X_W-1;to_right++)
        {
            if(calc_diff(mt9v03x_image[upward][to_right-5],mt9v03x_image[upward][to_right])>=Threshold_boundary )
            {
                yx[upward]=to_right-1;
                if(R_start_flag)
                {
                    R_start_flag--;
                    if(!R_start_flag)
                    {
                        R_start_x=to_right-1;
                        R_start_y=upward;
                        right_findflag=1;
                    }
                }
                break;
            }
            else if(to_right>=MT9V03X_W-2)
            {
                yx[upward]=MT9V03X_W-2;
                break;
            }
        }
        if(left_findflag==1&&right_findflag==1) break;
    }
}

uint8 Midline_white = 0;
uint8 Leftline_white = 0;
uint8 Rightline_white = 0;
/*-------------------------------------------------------------------------------------------------------------------
  @brief     ���Թ���ʼ�� ��ֵ����
  @note
-------------------------------------------------------------------------------------------------------------------*/
void fineonepoint_zeroone()
{
    uint8 i,j,upward,to_left,to_right;
    uint8 L_start_flag=2,R_start_flag=2;
    uint8 h=MT9V03X_H-2;//��ʼ��
    uint8 left_findflag = 0;
    uint8 right_findflag = 0;
    Finnalline=5;

    volatile int White_Column[MT9V03X_W]={0};//ÿ�а��г���
    for (i=2;i<=MT9V03X_W-2-1;i+=2)
    {
        for (j=MT9V03X_H-2;j >= 0; j--)
        {
            if(image[j][i] == 0)
                break;
            else
                White_Column[i]++;
        }
    }
    //����������������
     Longest_White_Column_Left[0] =0;
     Longest_White_Column_Right[0] = 0;
     if(left_circle_flag==1&&(circle_mode==2||circle_mode==3))
     {
         for(i=10;i<=MT9V03X_W/2;i+=2)
         {
             if (Longest_White_Column_Left[0] < White_Column[i])//�������һ��
             {
                 Longest_White_Column_Left[0] = White_Column[i];//��0���ǰ��г���
                 Longest_White_Column_Left[1] = i;              //��1�����±꣬��j��
             }
         }
         for(;h>0;h--)
         {
             if(h>=1&&image[h-1][ Longest_White_Column_Left[1] ]==0)
             {
                 Finnalline=h;//������
                 break;
             }
         }
     }
     else if(right_circle_flag==1&&(circle_mode==2||circle_mode==3))
     {
         for(i=MT9V03X_W-10;i>=MT9V03X_W/2;i-=2)
         {
             if (Longest_White_Column_Right[0] < White_Column[i])//�������һ��
             {
                 Longest_White_Column_Right[0] = White_Column[i];//��0���ǰ��г���
                 Longest_White_Column_Right[1] = i;              //��1�����±꣬��j��
             }
         }
         for(;h>0;h--)
         {
             if(h>=1&&image[h-1][ Longest_White_Column_Right[1] ]==0)
             {
                 Finnalline=h;//������
                 break;
             }
         }
     }
     else
     {
         for(i=10;i<=MT9V03X_W-10;i+=2)
         {
             if (Longest_White_Column_Left[0] < White_Column[i])//�������һ��
             {
                 Longest_White_Column_Left[0] = White_Column[i];//��0���ǰ��г���
                 Longest_White_Column_Left[1] = i;              //��1�����±꣬��j��
             }
         }
         for(i=MT9V03X_W-10;i>=10;i-=2)
         {
             if (Longest_White_Column_Right[0] < White_Column[i])//�������һ��
             {
                 Longest_White_Column_Right[0] = White_Column[i];//��0���ǰ��г���
                 Longest_White_Column_Right[1] = i;              //��1�����±꣬��j��
             }
         }
         for(;h>0;h--)
         {
             if(h>=1&&image[h-1][ Longest_White_Column_Left[1] ]==0)
             {
                 Finnalline=h;//������
                 break;
             }
         }
     }

     Midline_white = White_Column[MT9V03X_W/2];//�м��а�����
     Leftline_white = Longest_White_Column_Left[0];//�м��а�����
     Rightline_white = Longest_White_Column_Right[0];//�м��а�����

    for(upward=MT9V03X_H-2;upward>Finnalline;upward--)
    {
        //��߽�
        for(to_left= Longest_White_Column_Left[1]; to_left>0 ;to_left--)
        {
            if (image[upward][to_left-1]==0&&image[upward][to_left]==0&&image[upward][to_left+1]==255 )
            {
                zx[upward]=to_left+1;
                if(L_start_flag)
                {
                    L_start_flag--;
                    if(!L_start_flag)
                    {
                        L_start_x=to_left+1;
                        L_start_y=upward;
                        left_findflag=1;
                    }
                }
                break;
            }
            else if(to_left<=1)
            {
                zx[upward]=1;
                break;
            }
        }

       //�ұ߽�
        for(to_right= Longest_White_Column_Left[1]; to_right<MT9V03X_W-1;to_right++)
        {
            if(image[upward][to_right+1]==0&&image[upward][to_right]==0&&image[upward][to_right-1]==255 )
            {
                yx[upward]=to_right-1;
                if(R_start_flag)
                {
                    R_start_flag--;
                    if(!R_start_flag)
                    {
                        R_start_x=to_right-1;
                        R_start_y=upward;
                        right_findflag=1;
                    }
                }
                break;
            }
            else if(to_right>=MT9V03X_W-2)
            {
                yx[upward]=MT9V03X_W-2;
                break;
            }
        }
        if(left_findflag==1&&right_findflag==1) break;
    }
}

int16 calc_diff(int16 x, int16 y)
{
    return ( ((x-y)<<7)/(x+y) );
}

/*-------------------------------------------------------------------------------------------------------------------
  @brief    �л�ͼ����ģʽ
  @note
-------------------------------------------------------------------------------------------------------------------*/
void searchmode(int i)
{
    if(i==1)
    {
        Threshold = otsuThreshold(mt9v03x_image,0,MT9V03X_H,0,MT9V03X_W);
        ZeroOne(mt9v03x_image,0,MT9V03X_H,0,MT9V03X_W,Threshold);
        image_draw_rectan();
        fineonepoint();
        clear_find_point();
        search_neighborhood();
    }
    if(i==2)
    {
        Threshold = otsuThreshold(mt9v03x_image,0,MT9V03X_H,0,MT9V03X_W);
        ZeroOne(mt9v03x_image,0,MT9V03X_H,0,MT9V03X_W,Threshold);
        image_draw_rectan_zeroone();
        fineonepoint_zeroone();
        clear_find_point();
        search_neighborhood_zeroone();
    }
}


/*-------------------------------------------------------------------------------------------------------------------
  @brief     �������е����Լ��
  @param     ��ʼ�㣬��ֹ��
  @return    ��������0�����������ض��߳�����
  Sample     Monotonicity_Change_Left()
  @note
-------------------------------------------------------------------------------------------------------------------*/
int Monotonicity_Change_Left()
{
    int monotonicity_change_flag=0;
    if(L_edge_count > 9)
    {
        for(int i = 0; i<L_edge_count-9;i++)
        {
            if(L_edge[i].row>=L_edge[i+1].row&&L_edge[i+1].row>=L_edge[i+2].row&&
                    L_edge[i+2].row>=L_edge[i+3].row&&L_edge[i+3].row>=L_edge[i+4].row&&
                    L_edge[i+4].row<L_edge[i+5].row&&L_edge[i+5].row<=L_edge[i+6].row&&
                    L_edge[i+6].row<=L_edge[i+7].row&&L_edge[i+7].row<=L_edge[i+8].row)//�м䵥���Ըı�
            {
                monotonicity_change_flag=L_edge[i+4].row;
                break;
            }
        }
    }
    return monotonicity_change_flag;
}

/*-------------------------------------------------------------------------------------------------------------------
  @brief     �������е����Լ��
  @param     ��ʼ�㣬��ֹ��
  @return    ��������0�����������ض��߳�����
  Sample     Monotonicity_Change_Right()
  @note
-------------------------------------------------------------------------------------------------------------------*/
int Monotonicity_Change_Right()
{
    int monotonicity_change_flag=0;
    if(R_edge_count > 9)
    {
        for(int i = 0; i<R_edge_count-9;i++)
        {
            if(R_edge[i].row>=R_edge[i+1].row&&R_edge[i+1].row>=R_edge[i+2].row&&
                    R_edge[i+2].row>=R_edge[i+3].row&&R_edge[i+3].row>=R_edge[i+4].row&&
                    R_edge[i+4].row<R_edge[i+5].row&&R_edge[i+5].row<=R_edge[i+6].row&&
                    R_edge[i+6].row<=R_edge[i+7].row&&R_edge[i+7].row<=R_edge[i+8].row)//�м䵥���Ըı�
            {
                monotonicity_change_flag=R_edge[i+4].row;
                break;
            }
        }
    }
    return monotonicity_change_flag;
}

int forwardline=0;
/*-------------------------------------------------------------------------------------------------------------------
  @brief     ƫ�����
  @note
-------------------------------------------------------------------------------------------------------------------*/
float Err_Sum(void)
{
//    forwardline = Qianzhan;//46
    forwardline = 48;//46
    int i;
    float err=0;
    float err_last=0;
    float k = 1.0;
    err_last = Err;
    if(circle_mode==2)
    {
        forwardline = 70;
    }
    if(circle_mode==3)
    {
        forwardline = 70;
    }
    if(circle_mode==4)
    {
        forwardline = 70;
    }
    if(Barrier_Flag==1)
    {
        forwardline = 70;
    }
    if(SingleBridge_mode==2)
    {
        forwardline = 40;
//        k=0.5;
    }



    if(forwardline>=116) forwardline = 116;
    for(i=forwardline+3;i>forwardline;i--)//����������
    {
        err+= MT9V03X_W/2-wx[i] ;
    }
    err=k*err/3.0;
    if(circle_flag==1)
    {
        if(abs(err-err_last)>80)
        {
            err = err_last;
        }
    }
    else if(SingleBridge_Flag==1)
    {
        if(abs(err-err_last)>80)
        {
            err = err_last;
        }
    }
    else
    {
        if(abs(err-err_last)>40)
        {
            err = err_last;
        }
    }
    return err;
}



int16 L_SingleBridge_flag = 0;//��յ���ڱ�־
int16 L_SingleBridge_row = 0;//��յ�������
int16 L_SingleBridge_col = 0;//��յ�������
/*---------------------------------------------------------------
 ����    ����get_SingleBridgeleft_point
 ����    �ܡ����Ϲյ���
 ����    ������
 ���� �� ֵ��
 ��ע�����
 ----------------------------------------------------------------*/
void get_SingleBridgeleft_point(void)
{
    L_SingleBridge_flag = 0;// ��ʼ������
    L_SingleBridge_row = 0;
    L_SingleBridge_col = 0;
    if(1) //���ʹ��������յ�
    {
        for(int i=MT9V03X_H-1-5;i>Finnalline;i--)
        {
            if(
               abs(zx[i]-zx[i-1])<=3&&//�ǵ����ֵ���Ը���
               abs(zx[i-1]-zx[i-2])<=3&&
               abs(zx[i-2]-zx[i-3])<=3&&
                  (zx[i]-zx[i+2])>=10&&
                  (zx[i]-zx[i+3])>=10&&
                  (zx[i]-zx[i+4])>=10&&zx[i]<MT9V03X_W-30&&zx[i]>30)
            {
                L_SingleBridge_flag = 1;
                L_SingleBridge_row = i;
                L_SingleBridge_col = zx[i];
                break;
            }
        }
    }
}
int16 R_SingleBridge_flag = 0;//�ҹյ���ڱ�־
int16 R_SingleBridge_row = 0;//�ҹյ�������
int16 R_SingleBridge_col = 0;//�ҹյ�������
/*---------------------------------------------------------------
 ����    ����get_SingleBridgeright_point
 ����    �ܡ����Ϲյ���
 ����    ������
 ���� �� ֵ��
 ��ע�����
 ----------------------------------------------------------------*/
void get_SingleBridgeright_point(void)
{
    R_SingleBridge_flag = 0;//��ʼ������
    R_SingleBridge_row = 0;
    R_SingleBridge_col = 0;
    if(1)    //���ʹ�������ҹյ�
    {
        for(int i=MT9V03X_H-1-5;i>Finnalline;i--)
        {
            if(
               abs(yx[i-1]-yx[i])<=3&&//�ǵ����ֵ���Ը���
               abs(yx[i-2]-yx[i-1])<=3&&
               abs(yx[i-3]-yx[i-2])<=3&&
                  (yx[i+2]-yx[i])>=10&&
                  (yx[i+3]-yx[i])>=10&&
                  (yx[i+4]-yx[i])>=10&&yx[i]>30&&yx[i]<MT9V03X_W-30)
            {
                R_SingleBridge_flag = 1;
                R_SingleBridge_row = i;
                R_SingleBridge_col = yx[i];
                break;
            }
        }
    }
}
