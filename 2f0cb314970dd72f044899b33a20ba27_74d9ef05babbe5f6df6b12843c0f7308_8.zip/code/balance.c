
#include "zf_common_headfile.h"
#include "math.h"


int16 momentumwheel_pwm = 0;
int16 motor_pwm = 0;
int16 balance_pwm = 0;
float Total_roll = 0.0;
int PWM_OUT = 0;
int PWM_OUT_sudu = 0;
float Expectroll = 0.0;//��� ��Ԫ��181.0 ����0.6
float Expectroll_T = -2.0;//-5
float balance_velocity_PID_Encoder = 0.0;


//�ṹ�� ���嶨����pid.h
closed_loop_struct balance_velocity_pid;
closed_loop_struct balance_angle_p;
closed_loop_struct balance_gyro_pd;
closed_loop_struct balance_gyro_weizhi_pd;
closed_loop_struct balance_location_pid;
closed_loop_struct balance_encoder_pd;
closed_loop_struct balance_rollangle_pi;



/*-------------------------------------------------------------------------------------------------------------------
  @brief     �ٶȻ�
  @note      λ��ʽ
-------------------------------------------------------------------------------------------------------------------*/
void balance_encoder_PD(float encoder,float exspeed)
{
//*����ƫ�Ǹ��� ����Ϊ��
    balance_encoder_pd.error = exspeed - encoder;

    balance_encoder_pd.i_integral += balance_encoder_pd.error;

    if(balance_encoder_pd.i_integral <-500)      balance_encoder_pd.i_integral= -500; //�޷�
    else if(balance_encoder_pd.i_integral > 500)  balance_encoder_pd.i_integral= 500 ; //�޷�

    if(stop_flag == 1)
    {
        balance_encoder_pd.kp = 0.08;
    }
    else if(Ramp_Flag == 1)
    {
        balance_encoder_pd.kp = 0.02;
    }
    else if(Ramp_End_Flag == 1)
    {
        balance_encoder_pd.kp = 0.04;
    }
//    else if(Cross_Flag == 1)
//    {
//        balance_encoder_pd.kp = 0.1;
//    }
    else if(Jumpbarrier_mode == 2)
    {
        balance_encoder_pd.kp = 0.02;
    }
    else if(SingleBridge_mode == 1)
    {
        balance_encoder_pd.kp = 0.15;//15
    }
    else if(SingleBridge_mode == 2)
    {
        balance_encoder_pd.kp = 0.06;
    }
    else if(T_1s_flag == 1)
    {
        balance_encoder_pd.kp = 0.06;
    }
    else
    {
        balance_encoder_pd.kp = 0.04;
    }

    motor_pwm = balance_encoder_pd.kp * balance_encoder_pd.error + balance_encoder_pd.ki *balance_encoder_pd.i_integral + balance_encoder_pd.kd * (balance_encoder_pd.error - balance_encoder_pd.last_error);


    balance_encoder_pd.last_error = balance_encoder_pd.error;

}

void balance_encoder_pd_init(void)
{
    balance_encoder_pd.kp = 0.04f;//0.1/
    balance_encoder_pd.ki = 0.01f;//20
    balance_encoder_pd.kd = 0.01f;//
    balance_encoder_pd.i_integral = 0.f;
    balance_encoder_pd.last_error = 0.f;
    balance_encoder_pd.next_error = 0.f;
    balance_encoder_pd.error = 0.f;
}


/*-------------------------------------------------------------------------------------------------------------------
  @brief     ת��
  @note      λ��ʽ
-------------------------------------------------------------------------------------------------------------------*/
float balance_location_PID(float err)                //ת��
{
    float location_banlance_error;
    float a = 0.0; //0.0055
    float b = 21; //18
    float Gkd = 100.0;

    balance_location_pid.error = err;
    balance_location_pid.i_integral += balance_location_pid.error;

//        if(Cross_Flag==1)
//        {
//            balance_location_pid.kp = Lp_Cross;
//        }
        if(circle_flag==1)
        {
//            balance_location_pid.kp = Lp_Circle;
            balance_location_pid.kp = 20.0;
        }
//        else if(Ramp_Flag==1)
//        {
//            balance_location_pid.kp = Lp_Ramp;
//        }
//        else if(Ramp_End_Flag==1)
//        {
//            balance_location_pid.kp = Lp_Ramp_End;
//        }
//        else
//        {
//            balance_location_pid.kp = a * pow(balance_location_pid.error,2) + b; //Pֵ���ֵ�ɶ��κ�����ϵ//
//        }

    location_banlance_error =  balance_location_pid.kp * balance_location_pid.error + balance_location_pid.kd*(balance_location_pid.error- balance_location_pid.last_error)
            - Gkd * QEKF_INS.Gyro[2];

    if(circle_flag!=1&&Barrier_Flag!=1&&Zebra_Flag!=1&&Ramp_Flag!=1&&SingleBridge_Flag!=1&&Ramp_End_Flag!=1&&Jumpbarrier_Flag!=1)//&&Cross_Flag!=1
    {
        if(location_banlance_error>=600) location_banlance_error = 600;
        else if(location_banlance_error<=-600) location_banlance_error = -600;
    }

    balance_location_pid.last_error = balance_location_pid.error;

    return location_banlance_error;
}

void balance_location_pid_init(void)
{
    balance_location_pid.kp = 21.0f;//20.5
    balance_location_pid.ki = 0.0f;
    balance_location_pid.kd = 0.0f;//0.1
    balance_location_pid.i_integral = 0;
    balance_location_pid.last_error = 0;
    balance_location_pid.next_error = 0.f;
    balance_location_pid.error = 0;
}

/*-------------------------------------------------------------------------------------------------------------------
  @brief     �ٶȻ�
  @note      λ��ʽ
-------------------------------------------------------------------------------------------------------------------*/
float balance_velocity_PID(float encoder, float exspeed)                              //�ٶȻ�
{

    balance_velocity_PID_Encoder = exspeed - encoder;

    balance_velocity_pid.error = exspeed - encoder;
    balance_velocity_pid.i_integral += balance_velocity_pid.error;

    if(balance_velocity_pid.i_integral <-5)      balance_velocity_pid.i_integral= -5; //�޷�
    else if(balance_velocity_pid.i_integral >5)  balance_velocity_pid.i_integral= 5 ; //�޷�

    float vertical_banlance_error =  (balance_velocity_pid.kp * balance_velocity_pid.error + balance_velocity_pid.ki * (balance_velocity_pid.i_integral) + balance_velocity_pid.kd * + (balance_velocity_pid.error - balance_velocity_pid.last_error));
    balance_velocity_pid.last_error = balance_velocity_pid.error;

    return vertical_banlance_error;
}


void balance_velocity_pid_init(void)
{
    balance_velocity_pid.kp = 0.05f;//3.8
    balance_velocity_pid.ki = 0.0f;//0.42
    balance_velocity_pid.kd = 0.0f;//2.0
    balance_velocity_pid.i_integral = 0.f;
    balance_velocity_pid.last_error = 0.f;
    balance_velocity_pid.next_error = 0.f;
    balance_velocity_pid.error = 0.f;
}

/*-------------------------------------------------------------------------------------------------------------------
  @brief     �ǶȻ�
  @note      λ��ʽ
-------------------------------------------------------------------------------------------------------------------*/
float balance_angle_P(float realangle,float Expectangle)      //�ǶȻ�
{
    float k = 0.0;
    float angle_banlance_error;
    balance_angle_p.error = realangle - Expectangle ;
    balance_angle_p.i_integral += balance_angle_p.error;

    if(balance_angle_p.i_integral <-100)      balance_angle_p.i_integral= -100; //�޷�
    else if(balance_angle_p.i_integral > 100)  balance_angle_p.i_integral= 100 ; //�޷�


    angle_banlance_error =  balance_angle_p.kp * balance_angle_p.error + balance_angle_p.ki*balance_angle_p.i_integral+balance_angle_p.kd*(balance_angle_p.error- balance_angle_p.last_error);
    balance_angle_p.last_error = balance_angle_p.error;

    return angle_banlance_error;
}

void balance_angle_p_init(void)
{
    balance_angle_p.kp = 40.0f;//50
    balance_angle_p.ki = 0.0f;//
    balance_angle_p.kd = 30.0f;//0.01
    balance_angle_p.i_integral = 0.f;
    balance_angle_p.last_error = 0.f;
    balance_angle_p.next_error = 0.f;
    balance_angle_p.error = 0.f;
}

/*-------------------------------------------------------------------------------------------------------------------
  @brief     ���ٶȻ�
  @note      λ��ʽ
-------------------------------------------------------------------------------------------------------------------*/
void balance_gyro_weizhi_PD(float gyro,float angle_banlance_error)           //���ٶȻ� λ��ʽ
{
    int PWM_compensation = 0;

//*����ƫ�Ǹ��� ����Ϊ��
    balance_gyro_weizhi_pd.error = angle_banlance_error - gyro;

    balance_pwm = balance_gyro_weizhi_pd.kp * (balance_gyro_weizhi_pd.error) + balance_gyro_weizhi_pd.kd * (balance_gyro_weizhi_pd.error - balance_gyro_weizhi_pd.last_error);
    balance_gyro_weizhi_pd.last_error = balance_gyro_weizhi_pd.error;

    momentumwheel_pwm_control(balance_pwm);
//    momentumwheel_pwm_control(2000);

}

void balance_gyro_weizhi_pd_init(void)
{
    balance_gyro_weizhi_pd.kp = 20.0f;//1250
    balance_gyro_weizhi_pd.ki = 0.0f;//
    balance_gyro_weizhi_pd.kd = 60.0f;//100
    balance_gyro_weizhi_pd.i_integral = 0.f;
    balance_gyro_weizhi_pd.last_error = 0.f;
    balance_gyro_weizhi_pd.next_error = 0.f;
    balance_gyro_weizhi_pd.error = 0.f;
}

/*-------------------------------------------------------------------------------------------------------------------
  @brief    ���ٶȻ�
  @note     ����ʽ
-------------------------------------------------------------------------------------------------------------------*/
void balance_gyro_PD(float gyro,float angle_banlance_error)           //���ٶȻ� ����ʽ
{
    int PWM_compensation = 0;
//*����ƫ�Ǹ��� ����Ϊ��
    balance_gyro_pd.error = angle_banlance_error - gyro;

    momentumwheel_pwm = balance_gyro_pd.kp * (balance_gyro_pd.error - balance_gyro_pd.last_error) + balance_gyro_pd.ki*balance_gyro_pd.error + balance_gyro_pd.kd*(balance_gyro_pd.error-2*balance_gyro_pd.last_error+balance_gyro_pd.next_error);
    PWM_OUT+=momentumwheel_pwm;

    balance_gyro_pd.next_error = balance_gyro_pd.last_error;
    balance_gyro_pd.last_error = balance_gyro_pd.error;


        momentumwheel_pwm_control_f(-PWM_OUT + PWM_OUT_sudu);
        momentumwheel_pwm_control_a(+PWM_OUT + PWM_OUT_sudu);
}

void balance_gyro_pd_init(void)
{
    balance_gyro_pd.kp = 2000.0f;//1800
    balance_gyro_pd.ki = 75.8f;//93
    balance_gyro_pd.kd = 1000.0f;//0.15
    balance_gyro_pd.i_integral = 0.f;
    balance_gyro_pd.last_error = 0.f;
    balance_gyro_pd.next_error = 0.f;
    balance_gyro_pd.error = 0.f;
}


/*-------------------------------------------------------------------------------------------------------------------
  @brief    roll�Ჹ����
  @note     ����ʽ
-------------------------------------------------------------------------------------------------------------------*/
float balance_rollangle_PI(float roll,float expectroll)           //roll�Ჹ���� ����ʽ
{
    float compensate_roll;
    balance_rollangle_pi.error = expectroll - roll;

//    compensate_roll = balance_rollangle_pi.kp * (balance_rollangle_pi.error - balance_rollangle_pi.last_error)
//            + balance_rollangle_pi.ki*balance_rollangle_pi.error
//            + balance_rollangle_pi.kd*(balance_rollangle_pi.error-2*balance_rollangle_pi.last_error+balance_rollangle_pi.next_error);
//
//    Total_roll += compensate_roll;

    Total_roll = balance_rollangle_pi.kp * (balance_rollangle_pi.error) + balance_rollangle_pi.kd * (balance_rollangle_pi.error - balance_rollangle_pi.last_error);

    balance_rollangle_pi.next_error = balance_rollangle_pi.last_error;
    balance_rollangle_pi.last_error = balance_rollangle_pi.error;

    return Total_roll;
}


void balance_rollangle_pi_init(void)
{
    balance_rollangle_pi.kp = 2.0f;//
    balance_rollangle_pi.ki = 0.0f;//
    balance_rollangle_pi.kd = 5.0f;//
    balance_rollangle_pi.i_integral = 0.f;
    balance_rollangle_pi.last_error = 0.f;
    balance_rollangle_pi.next_error = 0.f;
    balance_rollangle_pi.error = 0.f;
}




