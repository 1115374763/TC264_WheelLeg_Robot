
#include "zf_common_headfile.h"
#include "math.h"

//�˵��ɵ�����
float Max_speed = 0.0;     //����ٶ�
float Base_speed = 0.0;    //�����ٶ�
float Circle_speed = 0.0;  //Բ���ٶ�
float Ramp_speed = 0.0;    //�µ��ٶ�
float Ramp_End_speed = 0.0;//�µ������ٶ�

float Qianzhan = 0.0;      //ǰհ

float Lp_Cross = 0.0;      //ʮ��ת��p
float Lp_Circle= 0.0;      //Բ��ת��p
float Lp_Ramp  = 0.0;      //�µ�ת��p
float Lp_Ramp_End  = 0.0;  //�µ�����ת��p
float Lp_Base  = 0.0;      //����ת��P

float Ap_Cross = 0.0;      //ʮ�ֽǶȻ�p
float Ap_Circle_Mode1= 0.0;      //Բ��һ�׶νǶȻ�p
float Ap_Circle = 0.0;      //Բ���ǶȻ���p
float Ap_Ramp  = 0.0;      //�µ��ǶȻ�p
float Ap_Base  = 0.0;      //�����ǶȻ�P

int Cross_enable = 1;
int Circle_enable = 1;
int Ramp_enable = 1;
int Zebra_enable = 1;
int Barrier_enable = 1;
int SingleBridge_enable = 1;
int Stopcar_enable = 1;
int Jumpbarrier_enable = 1;
int Ramp_sudu_en = 1;

int Time_1 = 0;
int Time_2 = 0;
int Time_Other = 0;

int LeftCircleLine_1 = 0;
int LeftCircleLine_4 = 0;
int RightCircleLine_1 = 0;
int RightCircleLine_4 = 0;

int tof_distance = 0;
int Mode_sudu = 0;
/*-------------------------------------------------------------------------------------------------------------------
  @brief     �˵�������ʼ��
  @note
-------------------------------------------------------------------------------------------------------------------*/
void MenuElementInit()
{
    if(Mode_sudu==0)
    {
        //�ٶȲ���
        Max_speed = 35.0;
        Base_speed = 26.0;
        Circle_speed = 26.0;
        Ramp_speed = 26.0;
        Ramp_End_speed = 24.0;

        //ǰհ
        Qianzhan = 35.0;

        //ת��
        Lp_Cross = 0.23;
        Lp_Circle= 0.23;
        Lp_Ramp  = 0.15;
        Lp_Ramp_End = 0.23;
        Lp_Base  = 0.22;

        //�ǶȻ�
        Ap_Cross = 0.065;
        Ap_Circle_Mode1= 0.07;
        Ap_Circle = 0.05;
        Ap_Ramp  = 0.08;
        Ap_Base  = 0.065;

        //Ԫ��ʹ�ܱ�־λ
        Cross_enable = 1;
        Circle_enable = 1;
        Ramp_enable = 1;
        Zebra_enable = 1;
        Barrier_enable = 1;
        Ramp_sudu_en = 0;

        //Բ����ʱ
        Time_1 = 600;
        Time_2 = 600;
        Time_Other = 600;

        //Բ������ ���Ŀ��� ���Ŀ���
        LeftCircleLine_1 = -5;
        LeftCircleLine_4 = -25;
        RightCircleLine_1 = 0;
        RightCircleLine_4 = 20;

        //tofʶ�����
        tof_distance = 350;
    }

    if(Mode_sudu==1)
    {
        //�ٶȲ���
        Max_speed = 35.0;
        Base_speed = 25.0;
        Circle_speed = 26.0;
        Ramp_speed = 26.0;
        Ramp_End_speed = 24.0;

        //ǰհ
        Qianzhan = 40.0;

        //ת��
        Lp_Cross = 0.23;
        Lp_Circle= 0.23;
        Lp_Ramp  = 0.15;
        Lp_Ramp_End = 0.23;
        Lp_Base  = 0.22;

        //�ǶȻ�
        Ap_Cross = 0.065;
        Ap_Circle_Mode1= 0.07;
        Ap_Circle = 0.05;
        Ap_Ramp  = 0.08;
        Ap_Base  = 0.065;

        //Ԫ��ʹ�ܱ�־λ
        Cross_enable = 1;
        Circle_enable = 1;
        Ramp_enable = 1;
        Zebra_enable = 1;
        Barrier_enable = 1;
        Ramp_sudu_en = 1;

        //Բ����ʱ
        Time_1 = 600;
        Time_2 = 600;
        Time_Other = 600;

        //Բ������ ���Ŀ��� ���Ŀ���
        LeftCircleLine_1 = -5;
        LeftCircleLine_4 = -25;
        RightCircleLine_1 = 0;
        RightCircleLine_4 = 20;

        //tofʶ�����
        tof_distance = 350;
    }

    if(Mode_sudu==2)
    {
        //�ٶȲ���
        Max_speed = 40.0;
        Base_speed = 27.0;
        Circle_speed = 26.0;
        Ramp_speed = 26.0;
        Ramp_End_speed = 24.0;

        //ǰհ
        Qianzhan = 30.0;

        //ת��
        Lp_Cross = 0.23;
        Lp_Circle= 0.23;
        Lp_Ramp  = 0.15;
        Lp_Ramp_End = 0.23;
        Lp_Base  = 0.22;

        //�ǶȻ�
        Ap_Cross = 0.065;
        Ap_Circle_Mode1= 0.07;
        Ap_Circle = 0.05;
        Ap_Ramp  = 0.08;
        Ap_Base  = 0.065;

        //Ԫ��ʹ�ܱ�־λ
        Cross_enable = 1;
        Circle_enable = 1;
        Ramp_enable = 1;
        Zebra_enable = 1;
        Barrier_enable = 1;
        Ramp_sudu_en = 0;

        //Բ����ʱ
        Time_1 = 600;
        Time_2 = 600;
        Time_Other = 600;

        //Բ������ ���Ŀ��� ���Ŀ���
        LeftCircleLine_1 = -5;
        LeftCircleLine_4 = -25;
        RightCircleLine_1 = 0;
        RightCircleLine_4 = 20;

        //tofʶ�����
        tof_distance = 350;
    }

    if(Mode_sudu==3)
    {
        //�ٶȲ���
        Max_speed = 45.0;
        Base_speed = 27.0;
        Circle_speed = 26.0;
        Ramp_speed = 26.0;
        Ramp_End_speed = 24.0;

        //ǰհ
        Qianzhan = 30.0;

        //ת��
        Lp_Cross = 0.23;
        Lp_Circle= 0.23;
        Lp_Ramp  = 0.15;
        Lp_Ramp_End = 0.23;
        Lp_Base  = 0.22;

        //�ǶȻ�
        Ap_Cross = 0.065;
        Ap_Circle_Mode1= 0.07;
        Ap_Circle = 0.05;
        Ap_Ramp  = 0.08;
        Ap_Base  = 0.065;

        //Ԫ��ʹ�ܱ�־λ
        Cross_enable = 1;
        Circle_enable = 1;
        Ramp_enable = 1;
        Zebra_enable = 1;
        Barrier_enable = 1;
        Ramp_sudu_en = 0;

        //Բ����ʱ
        Time_1 = 600;
        Time_2 = 600;
        Time_Other = 600;

        //Բ������ ���Ŀ��� ���Ŀ���
        LeftCircleLine_1 = -5;
        LeftCircleLine_4 = -25;
        RightCircleLine_1 = 0;
        RightCircleLine_4 = 20;

        //tofʶ�����
        tof_distance = 350;
    }
}
