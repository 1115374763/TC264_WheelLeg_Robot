/*
 * Attitude.h
 *
 *  Created on: 2024��3��9��
 *      Author: huawei
 */

#ifndef CODE_ATTITUDE_H_
#define CODE_ATTITUDE_H_
#include "zf_common_headfile.h"
void Attitude_Init(); //attitude init
void Attitude_Calculate();  //attitude calculate


#endif /* CODE_ATTITUDE_H_ */
