
#include "zf_common_headfile.h"
#include "math.h"

float momentumwheel_encoder_mid = 0.0;
float momentumwheel_encoder_chasu = 0.0;
int16 momentumwheel_encoder_forward = 0;
int16 momentumwheel_encoder_after = 0;

/*-------------------------------------------------------------------------------------------------------------------
  @brief     ��ͳ�����ʼ��
  @note
-------------------------------------------------------------------------------------------------------------------*/
void momentumwheel_init(void)
{
    pwm_init(ATOM0_CH3_P21_5, 500, 0);//��
    gpio_init(P21_4, GPO, 0, GPO_PUSH_PULL);
    encoder_quad_new_init(TIM3_ENCODER, TIM3_ENCODER_CH1_P02_6, TIM3_ENCODER_CH2_P02_7);

    pwm_init(ATOM2_CH2_P33_6, 500, 0);//��
    gpio_init(P33_7, GPO, 1, GPO_PUSH_PULL);
    encoder_quad_new_init(TIM4_ENCODER, TIM4_ENCODER_CH1_P02_8, TIM4_ENCODER_CH2_P00_9);
}

/*-------------------------------------------------------------------------------------------------------------------
  @brief     ��ͳ������
  @note
-------------------------------------------------------------------------------------------------------------------*/
void momentumwheel_pwm_control_f(int speed)
{
    if(speed>=9999) speed=9999;
    else if(speed<=-9999)   speed=-9999;
    if(speed<=0)
    {
        speed=-speed;
        pwm_set_duty(ATOM0_CH3_P21_5, speed);
        gpio_set_level(P21_4, 1);
    }
    else
     {
        pwm_set_duty(ATOM0_CH3_P21_5, speed);
        gpio_set_level(P21_4, 0);
     }
}

/*-------------------------------------------------------------------------------------------------------------------
  @brief     ��ͳ������
  @note
-------------------------------------------------------------------------------------------------------------------*/
void momentumwheel_pwm_control_a(int speed)
{
    if(speed>=9999) speed=9999;
    else if(speed<=-9999)   speed=-9999;
    if(speed<=0)
    {
        speed=-speed;
        pwm_set_duty(ATOM2_CH2_P33_6, speed);
        gpio_set_level(P33_7, 0);
    }
    else
     {
        pwm_set_duty(ATOM2_CH2_P33_6, speed);
        gpio_set_level(P33_7, 1);
     }
}



/*-------------------------------------------------------------------------------------------------------------------
  @brief     ��ˢ����
  @note
-------------------------------------------------------------------------------------------------------------------*/
void momentumwheel_pwm_control(int speed)
{

    if(speed>=9999) speed=9999;
    else if(speed<=-9999)   speed=-9999;
//    small_driver_set_duty(-speed+lora3a22_uart_transfer.joystick[0]/10+Err*2.0, speed+lora3a22_uart_transfer.joystick[0]/10+Err*2.0);   // ����ռ�ձ����

    small_driver_set_duty(-speed+location_banlance_error+SingleBridge_err, speed+location_banlance_error+SingleBridge_err);
}
