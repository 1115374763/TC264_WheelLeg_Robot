
#include "zf_common_headfile.h"
#include "math.h"


#pragma section all "cpu0_psram"


int8 page_index = 0;//ҳ����ʶ
int8 row_index = 1;//������ʶ

float delta = 0;
uint32 delta_flag_left = 1000000;
uint32 delta_flag_right = 1000000;

uint8 camera_enable = 0;
uint8 jiasu_enable = 1;
uint32 tim = 0;
uint8 motor_enable = 0;
extern int16 momentumwheel_encoder_forward;
extern int16 momentumwheel_encoder_after;

float angle_banlance_error = 0;
float location_banlance_error = 0;
float vertical_banlance_error = 0;
float servo_xunji_error = 0;
uint16 light = 212;

void (*current_operation_index)(void);

typedef struct
{
        int8 current;//��ǰ������
        int8 up;//���Ϸ�������
        int8 down;//���·�������
        int8 max_row_index;//ÿһҳ�������
        void (*current_operation)();        //��Ӧִ�к���
}key_table;

void page1(void);
void page2(void);
void page3(void);
void page4(void);
void page5(void);
void page6(void);
void page7(void);
void page8(void);

key_table table[8]=
{
        //�������ϣ��£�����У���ӡ����
        {0,7,1,7,(*page1)},
        {1,0,2,5,(*page2)},
        {2,1,3,5,(*page3)},
        {3,2,4,7,(*page4)},
        {4,3,5,7,(*page5)},
        {5,4,6,3,(*page6)},
        {6,5,7,3,(*page7)},
        {7,6,0,3,(*page8)},
};

/*-------------------------------------------------------------------------------------------------------------------
  @brief     �˵����ú���
  @note
-------------------------------------------------------------------------------------------------------------------*/
void Menu(void)
{
    row_control();
    adjust_control();


    current_operation_index=table[page_index].current_operation;        //��ȡ����

    (*current_operation_index)();//ִ�е�ǰ��������

    delta = 0;

}


//��������������
void row_control(void)
{

    if(key_up == 0 )
    {

        ips114_clear();
        page_index=table[page_index].current;
        row_index--;
        while(!key_up);//���ּ��
    }
    if(key_down== 0)
    {

        ips114_clear();
        page_index=table[page_index].current;
        row_index++;

        while(!key_down);//���ּ��key_down
    }
    if(key_mid== 0)
    {
        ips114_clear();
        motor_enable = 1;
        while(!key_mid);//���ּ��key_down
    }
    if(row_index > table[page_index].max_row_index)
    {
        page_index=table[page_index].down;
        row_index = 1;
    }
    else if(row_index < 1)
    {
        page_index=table[page_index].up;
        row_index = table[page_index].max_row_index;
    }
}

//��������������
void adjust_control(void)
{
    uint32 delta_flags = 0;
    if(key_left == 0)
    {

        ips114_clear();
        page_index=table[page_index].current;
        delta = 1;
        while(!key_left)
        {
            if(delta_flags >= delta_flag_left)
            {
                delta_flag_left = 50000;
                break;
            }
            else
            {
                delta_flags++;
            }
        }
    }
    else
    {
        delta_flag_left = 1000000;
    }
    if(key_right == 0)
    {

        ips114_clear();
        page_index=table[page_index].current;
        delta = -1;
        while(!key_right)
        {
            if(delta_flags >= delta_flag_right)
            {
                delta_flag_right = 50000;
                break;
            }
            else
            {
                delta_flags++;
            }
        }
    }
    else
    {
        delta_flag_right = 1000000;
    }
}

//��һҳ
void page1(void)
{

    ips114_show_string(0,0,"current page1");
    ips114_show_string(0,row_index*16,"->");
    switch(row_index)
    {
//        case 1:Jumpbarrier_Flag += 1*delta;
//        MenuElementInit();
//            break;

        case 2:Max_speed += 5*delta;
            break;

        case 3:Base_speed += 1*delta;
            break;

        case 4:motor_enable += 1*delta;
            break;

//        case 5:Expectroll_T += 0.5*delta;
//            break;
//
//        case 6:Qianzhan += 1*delta;
//            break;
//
//        case 7:Ramp_sudu_en += 1*delta;
//            break;
    }

    ips114_show_string(20,1*16,"Jump_Flag ");
    ips114_show_uint(100,1*16,Jumpbarrier_Flag,5);

    ips114_show_string(20,2*16,"left");
    ips114_show_int(100,2*16,lora3a22_uart_transfer.joystick[1]/10,4);

    ips114_show_string(20,3*16,"right ");
    ips114_show_int(100,3*16,lora3a22_uart_transfer.joystick[3]/10,4);

    ips114_show_string(20,4*16,"m_e ");
    ips114_show_uint(100,4*16,motor_enable,5);

    ips114_show_string(20,5*16,"yaw ");
    ips114_show_float(100,5*16,QEKF_INS.Yaw,3,2);

    ips114_show_string(20,6*16,"pitch ");
    ips114_show_float(100,6*16,QEKF_INS.Pitch,3,2);

    ips114_show_string(20,7*16,"Roll ");
    ips114_show_float(100,7*16,QEKF_INS.Roll,3,2);


//    ips114_show_string(20,2*16,"MaxSpeed ");
//    ips114_show_float(100,2*16,Max_speed,3,2);
//
//    ips114_show_string(20,3*16,"BaseSpeed ");
//    ips114_show_float(100,3*16,Base_speed,3,2);


//    ips114_show_string(20,5*16,"zero ");
//    ips114_show_float(100,5*16,Expectroll_T,3,2);

//    ips114_show_string(20,6*16,"Qianzhan ");
//    ips114_show_float(100,6*16,Qianzhan,3,2);

//    ips114_show_string(20,7*16,"Ramp_sudu_en ");
//    ips114_show_int(100,7*16,Ramp_sudu_en,4);






}

//�ڶ�ҳ
void page2(void)
{
    ips114_show_string(0,0,"current page2");
    ips114_show_string(0,row_index*16,"->");
    switch(row_index)
    {
        case 1:Lp_Cross += 0.01*delta;break;
        case 2:Lp_Circle+= 0.01*delta;break;
        case 3:Lp_Ramp  += 0.01*delta;break;
        case 4:Lp_Ramp_End += 0.01*delta;break;
        case 5:Lp_Base += 0.005*delta;break;
    }

//    ips114_show_string(20,1*16,"Lp_Cross ");
//    ips114_show_float(100,1*16,Lp_Cross,2,3);
//    ips114_show_string(20,2*16,"Lp_Circle ");
//    ips114_show_float(100,2*16,Lp_Circle,2,3);
//    ips114_show_string(20,3*16,"Lp_Ramp ");
//    ips114_show_float(100,3*16,Lp_Ramp,2,3);
//    ips114_show_string(20,4*16,"Lp_Ramp_End");
//    ips114_show_float(100,4*16,Lp_Ramp_End,2,3);
//    ips114_show_string(20,5*16,"Lp_Base ");
//    ips114_show_float(100,5*16,Lp_Base,2,3);

    ips114_show_int(190,0*16,tim,4);
    ips114_show_float(190,1*16, Err, 3, 3);

    ips114_show_gray_image(0, 0, mt9v03x_image, MT9V03X_W, MT9V03X_H, MT9V03X_W, MT9V03X_H, Threshold);//
    for(int i=0;i<MT9V03X_H;i++)
    {
        ips114_draw_point(zx[i], i, RGB565_RED);
        ips114_draw_point(yx[i], i, RGB565_GREEN);
        ips114_draw_point(wx[i], i, RGB565_BLUE);
//        ips114_draw_point(L_upcorner_col+5, i, RGB565_YELLOW);
//        ips114_draw_point(R_upcorner_col-5, i, RGB565_YELLOW);
    }
    for(int i=0;i<MT9V03X_W;i++)
    {
        ips114_draw_point(i, Finnalline, RGB565_YELLOW);
    }

}

//����ҳ
void page3(void)
{

    ips114_show_string(0,0,"current page3");
    ips114_show_string(0,row_index*16,"->");
    switch(row_index)
    {
        case 1:Ap_Cross += 0.005*delta;break;
        case 2:Ap_Circle_Mode1 += 0.005*delta;break;
        case 3:Ap_Circle += 0.005*delta;break;
        case 4:Ap_Ramp += 0.005*delta;break;
        case 5:Ap_Base += 0.005*delta;break;
    }
//    ips114_show_string(20,1*16,"Ap_Cross ");
//    ips114_show_float(100,1*16,Ap_Cross,2,4);
//    ips114_show_string(20,2*16,"Ap_Circle_M1 ");
//    ips114_show_float(100,2*16,Ap_Circle_Mode1,2,4);
//    ips114_show_string(20,3*16,"Ap_Circle ");
//    ips114_show_float(100,3*16,Ap_Circle,2,4);
//    ips114_show_string(20,4*16,"Ap_Ramp ");
//    ips114_show_float(100,4*16,Ap_Ramp,2,4);
//    ips114_show_string(20,5*16,"Ap_Base ");
//    ips114_show_float(100,5*16,Ap_Base,2,4);
    ips114_show_gray_image(0, 0, mt9v03x_image, MT9V03X_W, MT9V03X_H, MT9V03X_W, MT9V03X_H, 0);//Threshold
}

//����ҳ
void page4(void)
{

    ips114_show_string(0,0,"current page4");
    ips114_show_string(0,row_index*16,"->");
    switch(row_index)
    {
        case 3:Circle_enable += 1*delta;break;
        case 4:Cross_enable += 1*delta;break;
        case 5:Ramp_enable += 1*delta;break;
        case 6:Zebra_enable += 1*delta;break;
        case 7:Ramp_sudu_en += 1*delta;break;
    }
    ips114_show_string(20,1*16,"a ");
    ips114_show_int(100,1*16,momentumwheel_encoder_forward,4);
    ips114_show_string(20,2*16,"b ");
    ips114_show_int(100,2*16,momentumwheel_encoder_after,4);

    ips114_show_string(20,3*16,"Circle_enable ");
    ips114_show_int(100,3*16,Circle_enable,4);

    ips114_show_string(20,4*16,"Cross_enable ");
    ips114_show_int(100,4*16,Cross_enable,4);

    ips114_show_string(20,5*16,"Ramp_enable ");
    ips114_show_int(100,5*16,Ramp_enable,4);

    ips114_show_string(20,6*16,"Zebra_enable ");
    ips114_show_int(100,6*16,Zebra_enable,4);

    ips114_show_string(20,7*16,"Ramp_sudu_en ");
    ips114_show_int(100,7*16,Ramp_sudu_en,4);

}

//����ҳ
void page5(void)
{

    ips114_show_string(0,0,"current page5");
    ips114_show_string(0,row_index*16,"->");
    switch(row_index)
    {
        case 1:Time_1 += 100*delta;break;
        case 2:Time_2 += 100*delta;break;
        case 3:Time_Other += 100*delta;break;
        case 4:LeftCircleLine_1 += 5*delta;break;
        case 5:LeftCircleLine_4 += 5*delta;break;
        case 6:RightCircleLine_1 += 5*delta;break;
        case 7:RightCircleLine_4 += 5*delta;break;
    }
    ips114_show_string(20,1*16,"Time_1 ");
    ips114_show_int(100,1*16,Time_1,4);

    ips114_show_string(20,2*16,"Time_2 ");
    ips114_show_int(100,2*16,Time_2,4);

    ips114_show_string(20,3*16,"Time_Other ");
    ips114_show_int(100,3*16,Time_Other,4);

    ips114_show_string(20,4*16,"L_1 ");
    ips114_show_int(100,4*16,LeftCircleLine_1,4);

    ips114_show_string(20,5*16,"L_4 ");
    ips114_show_int(100,5*16,LeftCircleLine_4,4);

    ips114_show_string(20,6*16,"R_1 ");
    ips114_show_int(100,6*16,RightCircleLine_1,4);

    ips114_show_string(20,7*16,"R_4 ");
    ips114_show_int(100,7*16,RightCircleLine_4,4);
}

//����ҳ
void page6(void)
{

    ips114_show_string(0,0,"current page6");
    ips114_show_string(0,row_index*16,"->");
    switch(row_index)
    {
    }

}

//����ҳ
void page7(void)
{

    ips114_show_string(0,0,"current page7");
    ips114_show_string(0,row_index*16,"->");
    switch(row_index)
    {
        case 1:Circle_speed += 1*delta;break;
        case 2:Ramp_speed += 1*delta;break;
        case 3:Ramp_End_speed += 1*delta;break;
    }
    ips114_show_string(20,1*16,"Circle_speed ");
    ips114_show_float(100,1*16,Circle_speed,3,2);

    ips114_show_string(20,2*16,"Ramp_speed ");
    ips114_show_float(100,2*16,Ramp_speed,3,2);

    ips114_show_string(20,3*16,"Ramp_E_speed ");
    ips114_show_float(100,3*16,Ramp_End_speed,3,2);

//    ips114_show_binary_image (0, 0, image, MT9V03X_W, MT9V03X_H, MT9V03X_W, MT9V03X_H);
}

//����ҳ
void page8(void)
{

    ips114_show_string(0,0,"current page8");
    ips114_show_string(0,row_index*16,"->");
    switch(row_index)
    {
//        case 1:light += 100*delta;mt9v03x_set_exposure_time(light);break;
//        case 2:tof_distance += 50*delta;break;
    }
//    ips114_show_string(190,0*16,"light and tof");
//    ips114_show_int(190,0*16,dl1b_distance_mm,4);
//    ips114_show_float(190,0*16, Err, 3, 3);
    ips114_show_int(190,0*16,SingleBridge_width_chazhi,4);
    ips114_show_int(190,1*16,SingleBridge_width_left,4);
    ips114_show_int(190,2*16,SingleBridge_width_right,4);

//    ips114_show_string(190,0*16,"zebra");
//    ips114_show_int(190,1*16,dl1b_distance_mm,4);
//    ips114_show_int(190,2*16,Ramp_mode,3);

//    ips114_show_uint(190,1*16,Boundry_Start_Left,3);
//    ips114_show_uint(190,2*16,Boundry_Start_Right,3);
//    ips114_show_float (190, 2*16, Err, 3, 2);

    ips114_show_string(190,3*16,"cross");
    ips114_show_int(190,4*16,L_corner_flag,3);
    ips114_show_int(190,5*16,R_corner_flag,3);
    ips114_show_int(190,6*16,L_upcorner_flag,3);
    ips114_show_int(190,7*16,R_upcorner_flag,3);

//    ips114_show_int(190,9*16,circle_flag,3);
//    ips114_show_int(190,10*16,Cross_Flag,3);
//    ips114_show_int(190,11*16,Zebra_Flag,3);
//    ips114_show_int(190,12*16,Ramp_Flag,3);
//    ips114_show_int(190,13*16,Barrier_Flag,3);
//    ips114_show_int(190,14*16,SingleBridge_Flag,3);


    ips114_show_gray_image(0, 0, mt9v03x_image, MT9V03X_W, MT9V03X_H, MT9V03X_W, MT9V03X_H, Threshold);

    for(int i=0;i<MT9V03X_H;i++)
    {
        ips114_draw_point(zx[i], i, RGB565_RED);
        ips114_draw_point(yx[i], i, RGB565_GREEN);
        ips114_draw_point(wx[i], i, RGB565_BLUE);
//        ips114_draw_point(L_upcorner_col+5, i, RGB565_YELLOW);
//        ips114_draw_point(R_upcorner_col-5, i, RGB565_YELLOW);
    }
    for(int i=0;i<MT9V03X_W;i++)
    {
        ips114_draw_point(i, Finnalline, RGB565_YELLOW);
    }

}

/*-------------------------------------------------------------------------------------------------------------------
  @brief     ��ʾ��ʼ��
  @note
-------------------------------------------------------------------------------------------------------------------*/
void disply_init(void)
{
    ips114_set_dir(0);
    ips114_set_font(0);
    ips114_set_color(RGB565_39C5BB, RGB565_BLACK);
    ips114_init();
    gpio_init(P11_10, GPI, GPIO_HIGH, GPI_PULL_UP);
    gpio_init(P11_11, GPI, GPIO_HIGH, GPI_PULL_UP);
    gpio_init(P11_2, GPI, GPIO_HIGH, GPI_PULL_UP);
    gpio_init(P11_3, GPI, GPIO_HIGH, GPI_PULL_UP);
    gpio_init(P11_9, GPI, GPIO_HIGH, GPI_PULL_UP);

//    gpio_init(P20_6, GPI, GPIO_HIGH, GPI_PULL_UP);
//    gpio_init(P20_7, GPI, GPIO_HIGH, GPI_PULL_UP);
//    gpio_init(P11_2, GPI, GPIO_HIGH, GPI_PULL_UP);
//    gpio_init(P11_3, GPI, GPIO_HIGH, GPI_PULL_UP);
//    gpio_init(P33_12, GPI, GPIO_HIGH, GPI_PULL_UP);
}


/*-------------------------------------------------------------------------------------------------------------------
  @brief     ���ݶ�ȡ
  @note
-------------------------------------------------------------------------------------------------------------------*/
void data_read()
{
    flash_read_page_to_buffer(0, 5);           // �����ݴ� flash ��ȡ��������
    //��һҳ
    Expectroll_T = flash_union_buffer[0].float_type;
    Max_speed =     flash_union_buffer[1].float_type;
    Base_speed = flash_union_buffer[2].float_type ;
    Qianzhan =     flash_union_buffer[3].float_type;
}


/*-------------------------------------------------------------------------------------------------------------------
  @brief     ����д��
  @note
-------------------------------------------------------------------------------------------------------------------*/
void data_write()
{
    if(flash_check(0, 5))                      // �ж��Ƿ�������
        flash_erase_page(0, 5);                // ������һҳ
        flash_buffer_clear();
        //��һҳ
        flash_union_buffer[0].float_type = Expectroll_T;
        flash_union_buffer[1].float_type = Max_speed;
        flash_union_buffer[2].float_type = Base_speed;
        flash_union_buffer[3].float_type = Qianzhan;
        //�ڶ�ҳ

        flash_write_page_from_buffer(0, 5);
}





