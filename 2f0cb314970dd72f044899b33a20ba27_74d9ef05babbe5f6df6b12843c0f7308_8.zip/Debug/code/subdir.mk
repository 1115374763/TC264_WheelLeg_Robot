################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../code/Attitude.c \
../code/MenuElement.c \
../code/QuaternionEKF.c \
../code/balance.c \
../code/camera.c \
../code/disply.c \
../code/element.c \
../code/kalman_filter.c \
../code/matrix.c \
../code/momentumwheel.c \
../code/pid.c \
../code/servo.c \
../code/small_driver_uart_control.c \
../code/swj.c \
../code/vmc.c \
../code/zf_device_dot_matrix_screen.c \
../code/zf_device_lora3a22.c \
../code/zf_device_tld7002.c 

COMPILED_SRCS += \
./code/Attitude.src \
./code/MenuElement.src \
./code/QuaternionEKF.src \
./code/balance.src \
./code/camera.src \
./code/disply.src \
./code/element.src \
./code/kalman_filter.src \
./code/matrix.src \
./code/momentumwheel.src \
./code/pid.src \
./code/servo.src \
./code/small_driver_uart_control.src \
./code/swj.src \
./code/vmc.src \
./code/zf_device_dot_matrix_screen.src \
./code/zf_device_lora3a22.src \
./code/zf_device_tld7002.src 

C_DEPS += \
./code/Attitude.d \
./code/MenuElement.d \
./code/QuaternionEKF.d \
./code/balance.d \
./code/camera.d \
./code/disply.d \
./code/element.d \
./code/kalman_filter.d \
./code/matrix.d \
./code/momentumwheel.d \
./code/pid.d \
./code/servo.d \
./code/small_driver_uart_control.d \
./code/swj.d \
./code/vmc.d \
./code/zf_device_dot_matrix_screen.d \
./code/zf_device_lora3a22.d \
./code/zf_device_tld7002.d 

OBJS += \
./code/Attitude.o \
./code/MenuElement.o \
./code/QuaternionEKF.o \
./code/balance.o \
./code/camera.o \
./code/disply.o \
./code/element.o \
./code/kalman_filter.o \
./code/matrix.o \
./code/momentumwheel.o \
./code/pid.o \
./code/servo.o \
./code/small_driver_uart_control.o \
./code/swj.o \
./code/vmc.o \
./code/zf_device_dot_matrix_screen.o \
./code/zf_device_lora3a22.o \
./code/zf_device_tld7002.o 


# Each subdirectory must supply rules for building sources it contributes
code/%.src: ../code/%.c code/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: TASKING C/C++ Compiler'
	cctc -cs --dep-file="$(basename $@).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/Debug/TASKING_C_C___Compiler-Include_paths.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=3 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<" && \
	if [ -f "$(basename $@).d" ]; then sed.exe -r  -e 's/\b(.+\.o)\b/code\/\1/g' -e 's/\\/\//g' -e 's/\/\//\//g' -e 's/"//g' -e 's/([a-zA-Z]:\/)/\L\1/g' -e 's/\d32:/@TARGET_DELIMITER@/g; s/\\\d32/@ESCAPED_SPACE@/g; s/\d32/\\\d32/g; s/@ESCAPED_SPACE@/\\\d32/g; s/@TARGET_DELIMITER@/\d32:/g' "$(basename $@).d" > "$(basename $@).d_sed" && cp "$(basename $@).d_sed" "$(basename $@).d" && rm -f "$(basename $@).d_sed" 2>/dev/null; else echo 'No dependency file to process';fi
	@echo 'Finished building: $<'
	@echo ' '

code/%.o: ./code/%.src code/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: TASKING Assembler'
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


clean: clean-code

clean-code:
	-$(RM) ./code/Attitude.d ./code/Attitude.o ./code/Attitude.src ./code/MenuElement.d ./code/MenuElement.o ./code/MenuElement.src ./code/QuaternionEKF.d ./code/QuaternionEKF.o ./code/QuaternionEKF.src ./code/balance.d ./code/balance.o ./code/balance.src ./code/camera.d ./code/camera.o ./code/camera.src ./code/disply.d ./code/disply.o ./code/disply.src ./code/element.d ./code/element.o ./code/element.src ./code/kalman_filter.d ./code/kalman_filter.o ./code/kalman_filter.src ./code/matrix.d ./code/matrix.o ./code/matrix.src ./code/momentumwheel.d ./code/momentumwheel.o ./code/momentumwheel.src ./code/pid.d ./code/pid.o ./code/pid.src ./code/servo.d ./code/servo.o ./code/servo.src ./code/small_driver_uart_control.d ./code/small_driver_uart_control.o ./code/small_driver_uart_control.src ./code/swj.d ./code/swj.o ./code/swj.src ./code/vmc.d ./code/vmc.o ./code/vmc.src ./code/zf_device_dot_matrix_screen.d ./code/zf_device_dot_matrix_screen.o ./code/zf_device_dot_matrix_screen.src ./code/zf_device_lora3a22.d ./code/zf_device_lora3a22.o ./code/zf_device_lora3a22.src ./code/zf_device_tld7002.d ./code/zf_device_tld7002.o ./code/zf_device_tld7002.src

.PHONY: clean-code

