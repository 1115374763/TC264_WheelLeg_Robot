code/TLD7002_driver/TLD7002_ServiceLayer.o :	../code/TLD7002_driver/TLD7002_ServiceLayer.c
../code/TLD7002_driver/TLD7002_ServiceLayer.c :
code/TLD7002_driver/TLD7002_ServiceLayer.o :	../code/TLD7002_driver/TLD7002_ServiceLayer.h
../code/TLD7002_driver/TLD7002_ServiceLayer.h :
code/TLD7002_driver/TLD7002_ServiceLayer.o :	../code/TLD7002_driver/TLD7002_ControlLayer.h
../code/TLD7002_driver/TLD7002_ControlLayer.h :
code/TLD7002_driver/TLD7002_ServiceLayer.o :	../code/TLD7002_driver/TLD7002.h
../code/TLD7002_driver/TLD7002.h :
code/TLD7002_driver/TLD7002_ServiceLayer.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/Platform_Types.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/Platform_Types.h :
code/TLD7002_driver/TLD7002_ServiceLayer.o :	../code/TLD7002_driver/TLD7002_Definitions.h
../code/TLD7002_driver/TLD7002_Definitions.h :
code/TLD7002_driver/TLD7002_ServiceLayer.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/zf_common/zf_common_typedef.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/zf_common/zf_common_typedef.h :
code/TLD7002_driver/TLD7002_ServiceLayer.o :	c:/Infineon/AURIX-Studio-1.9.16/tools/Compilers/Tasking_1.1r8/ctc/include/math.h
c:/Infineon/AURIX-Studio-1.9.16/tools/Compilers/Tasking_1.1r8/ctc/include/math.h :
code/TLD7002_driver/TLD7002_ServiceLayer.o :	c:/Infineon/AURIX-Studio-1.9.16/tools/Compilers/Tasking_1.1r8/ctc/include/typeinfo.h
c:/Infineon/AURIX-Studio-1.9.16/tools/Compilers/Tasking_1.1r8/ctc/include/typeinfo.h :
code/TLD7002_driver/TLD7002_ServiceLayer.o :	c:/Infineon/AURIX-Studio-1.9.16/tools/Compilers/Tasking_1.1r8/ctc/include/stdio.h
c:/Infineon/AURIX-Studio-1.9.16/tools/Compilers/Tasking_1.1r8/ctc/include/stdio.h :
code/TLD7002_driver/TLD7002_ServiceLayer.o :	c:/Infineon/AURIX-Studio-1.9.16/tools/Compilers/Tasking_1.1r8/ctc/include/stdarg.h
c:/Infineon/AURIX-Studio-1.9.16/tools/Compilers/Tasking_1.1r8/ctc/include/stdarg.h :
code/TLD7002_driver/TLD7002_ServiceLayer.o :	c:/Infineon/AURIX-Studio-1.9.16/tools/Compilers/Tasking_1.1r8/ctc/include/stdint.h
c:/Infineon/AURIX-Studio-1.9.16/tools/Compilers/Tasking_1.1r8/ctc/include/stdint.h :
code/TLD7002_driver/TLD7002_ServiceLayer.o :	c:/Infineon/AURIX-Studio-1.9.16/tools/Compilers/Tasking_1.1r8/ctc/include/string.h
c:/Infineon/AURIX-Studio-1.9.16/tools/Compilers/Tasking_1.1r8/ctc/include/string.h :
code/TLD7002_driver/TLD7002_ServiceLayer.o :	c:/Infineon/AURIX-Studio-1.9.16/tools/Compilers/Tasking_1.1r8/ctc/include/stdlib.h
c:/Infineon/AURIX-Studio-1.9.16/tools/Compilers/Tasking_1.1r8/ctc/include/stdlib.h :
code/TLD7002_driver/TLD7002_ServiceLayer.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/ifx_types.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/ifx_types.h :
code/TLD7002_driver/TLD7002_ServiceLayer.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/Compilers.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/Compilers.h :
code/TLD7002_driver/TLD7002_ServiceLayer.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Configurations/Ifx_Cfg.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Configurations/Ifx_Cfg.h :
code/TLD7002_driver/TLD7002_ServiceLayer.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerTasking.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerTasking.h :
code/TLD7002_driver/TLD7002_ServiceLayer.o :	c:/Infineon/AURIX-Studio-1.9.16/tools/Compilers/Tasking_1.1r8/ctc/include/stddef.h
c:/Infineon/AURIX-Studio-1.9.16/tools/Compilers/Tasking_1.1r8/ctc/include/stddef.h :
code/TLD7002_driver/TLD7002_ServiceLayer.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/Ifx_TypesTasking.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/Ifx_TypesTasking.h :
code/TLD7002_driver/TLD7002_ServiceLayer.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/PLATFORM_TYPES.H
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/PLATFORM_TYPES.H :
