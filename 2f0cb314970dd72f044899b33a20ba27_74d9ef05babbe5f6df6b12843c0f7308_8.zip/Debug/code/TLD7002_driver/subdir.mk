################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../code/TLD7002_driver/TLD7002FuncLayer.c \
../code/TLD7002_driver/TLD7002_ControlLayer.c \
../code/TLD7002_driver/TLD7002_ServiceLayer.c 

COMPILED_SRCS += \
./code/TLD7002_driver/TLD7002FuncLayer.src \
./code/TLD7002_driver/TLD7002_ControlLayer.src \
./code/TLD7002_driver/TLD7002_ServiceLayer.src 

C_DEPS += \
./code/TLD7002_driver/TLD7002FuncLayer.d \
./code/TLD7002_driver/TLD7002_ControlLayer.d \
./code/TLD7002_driver/TLD7002_ServiceLayer.d 

OBJS += \
./code/TLD7002_driver/TLD7002FuncLayer.o \
./code/TLD7002_driver/TLD7002_ControlLayer.o \
./code/TLD7002_driver/TLD7002_ServiceLayer.o 


# Each subdirectory must supply rules for building sources it contributes
code/TLD7002_driver/%.src: ../code/TLD7002_driver/%.c code/TLD7002_driver/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: TASKING C/C++ Compiler'
	cctc -cs --dep-file="$(basename $@).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/Debug/TASKING_C_C___Compiler-Include_paths.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=3 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<" && \
	if [ -f "$(basename $@).d" ]; then sed.exe -r  -e 's/\b(.+\.o)\b/code\/TLD7002_driver\/\1/g' -e 's/\\/\//g' -e 's/\/\//\//g' -e 's/"//g' -e 's/([a-zA-Z]:\/)/\L\1/g' -e 's/\d32:/@TARGET_DELIMITER@/g; s/\\\d32/@ESCAPED_SPACE@/g; s/\d32/\\\d32/g; s/@ESCAPED_SPACE@/\\\d32/g; s/@TARGET_DELIMITER@/\d32:/g' "$(basename $@).d" > "$(basename $@).d_sed" && cp "$(basename $@).d_sed" "$(basename $@).d" && rm -f "$(basename $@).d_sed" 2>/dev/null; else echo 'No dependency file to process';fi
	@echo 'Finished building: $<'
	@echo ' '

code/TLD7002_driver/%.o: ./code/TLD7002_driver/%.src code/TLD7002_driver/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: TASKING Assembler'
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


clean: clean-code-2f-TLD7002_driver

clean-code-2f-TLD7002_driver:
	-$(RM) ./code/TLD7002_driver/TLD7002FuncLayer.d ./code/TLD7002_driver/TLD7002FuncLayer.o ./code/TLD7002_driver/TLD7002FuncLayer.src ./code/TLD7002_driver/TLD7002_ControlLayer.d ./code/TLD7002_driver/TLD7002_ControlLayer.o ./code/TLD7002_driver/TLD7002_ControlLayer.src ./code/TLD7002_driver/TLD7002_ServiceLayer.d ./code/TLD7002_driver/TLD7002_ServiceLayer.o ./code/TLD7002_driver/TLD7002_ServiceLayer.src

.PHONY: clean-code-2f-TLD7002_driver

