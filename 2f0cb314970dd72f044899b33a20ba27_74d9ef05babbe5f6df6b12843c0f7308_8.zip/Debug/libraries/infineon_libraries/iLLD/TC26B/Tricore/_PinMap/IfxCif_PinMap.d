libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCif_PinMap.o :	../libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCif_PinMap.c
../libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCif_PinMap.c :
libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCif_PinMap.o :	../libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCif_PinMap.h
../libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCif_PinMap.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCif_PinMap.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxCif_reg.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxCif_reg.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCif_PinMap.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxCif_regdef.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxCif_regdef.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCif_PinMap.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/Ifx_TypesReg.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/Ifx_TypesReg.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCif_PinMap.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxCif_cfg.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxCif_cfg.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCif_PinMap.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/Ifx_Types.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/Ifx_Types.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCif_PinMap.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/Compilers.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/Compilers.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCif_PinMap.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Configurations/Ifx_Cfg.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Configurations/Ifx_Cfg.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCif_PinMap.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerTasking.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerTasking.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCif_PinMap.o :	c:/Infineon/AURIX-Studio-1.9.16/tools/Compilers/Tasking_1.1r8/ctc/include/stddef.h
c:/Infineon/AURIX-Studio-1.9.16/tools/Compilers/Tasking_1.1r8/ctc/include/stddef.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCif_PinMap.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/Platform_Types.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/Platform_Types.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCif_PinMap.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/Ifx_TypesTasking.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/Ifx_TypesTasking.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCif_PinMap.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Port/Std/IfxPort.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Port/Std/IfxPort.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCif_PinMap.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxPort_cfg.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxPort_cfg.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCif_PinMap.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/IfxCpu_Intrinsics.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/IfxCpu_Intrinsics.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCif_PinMap.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/Ifx_Types.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/Ifx_Types.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCif_PinMap.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/IfxCpu_IntrinsicsTasking.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/IfxCpu_IntrinsicsTasking.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCif_PinMap.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/Ifx_Types.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/Ifx_Types.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCif_PinMap.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxPort_reg.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxPort_reg.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCif_PinMap.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxPort_regdef.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxPort_regdef.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCif_PinMap.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Scu/Std/IfxScuWdt.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Scu/Std/IfxScuWdt.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCif_PinMap.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxScu_cfg.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxScu_cfg.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCif_PinMap.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxScu_bf.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxScu_bf.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCif_PinMap.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxFlash_bf.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxFlash_bf.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCif_PinMap.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxScu_reg.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxScu_reg.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCif_PinMap.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxScu_regdef.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxScu_regdef.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCif_PinMap.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Scu/Std/IfxScuWdt.asm.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Scu/Std/IfxScuWdt.asm.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCif_PinMap.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/IfxCpu_Intrinsics.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/IfxCpu_Intrinsics.h :
