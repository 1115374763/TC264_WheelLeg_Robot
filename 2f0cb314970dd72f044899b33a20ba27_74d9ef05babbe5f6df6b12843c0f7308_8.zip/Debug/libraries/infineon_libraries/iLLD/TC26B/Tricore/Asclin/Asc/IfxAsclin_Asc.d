libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	../libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.c
../libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.c :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	../libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.h
../libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Std/IfxAsclin.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Std/IfxAsclin.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxAsclin_cfg.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxAsclin_cfg.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/Ifx_Types.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/Ifx_Types.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/Compilers.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/Compilers.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Configurations/Ifx_Cfg.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Configurations/Ifx_Cfg.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerTasking.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerTasking.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Infineon/AURIX-Studio-1.9.16/tools/Compilers/Tasking_1.1r8/ctc/include/stddef.h
c:/Infineon/AURIX-Studio-1.9.16/tools/Compilers/Tasking_1.1r8/ctc/include/stddef.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/Platform_Types.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/Platform_Types.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/Ifx_TypesTasking.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/Ifx_TypesTasking.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxAsclin_reg.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxAsclin_reg.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxAsclin_regdef.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxAsclin_regdef.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/Ifx_TypesReg.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/Ifx_TypesReg.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Scu/Std/IfxScuCcu.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Scu/Std/IfxScuCcu.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxScu_cfg.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxScu_cfg.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxScu_bf.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxScu_bf.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxFlash_bf.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxFlash_bf.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Scu/Std/IfxScuWdt.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Scu/Std/IfxScuWdt.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxScu_reg.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxScu_reg.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxScu_regdef.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxScu_regdef.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Scu/Std/IfxScuWdt.asm.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Scu/Std/IfxScuWdt.asm.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/IfxCpu_Intrinsics.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/IfxCpu_Intrinsics.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/Ifx_Types.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/Ifx_Types.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/IfxCpu_IntrinsicsTasking.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/IfxCpu_IntrinsicsTasking.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/Ifx_Types.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/Ifx_Types.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/IfxCpu.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/IfxCpu.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxCpu_cfg.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxCpu_cfg.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/IfxCpu_Intrinsics.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/IfxCpu_Intrinsics.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxCpu_reg.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxCpu_reg.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxCpu_regdef.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxCpu_regdef.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxSrc_reg.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxSrc_reg.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxSrc_regdef.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxSrc_regdef.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxStm_reg.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxStm_reg.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxStm_regdef.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxStm_regdef.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Service/CpuGeneric/_Utilities/Ifx_Assert.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Service/CpuGeneric/_Utilities/Ifx_Assert.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Scu/Std/IfxScuWdt.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Scu/Std/IfxScuWdt.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Scu/Std/IfxScuCcu.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Scu/Std/IfxScuCcu.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxFlash_reg.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxFlash_reg.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxFlash_regdef.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxFlash_regdef.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxScu_PinMap.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxScu_PinMap.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Port/Std/IfxPort.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Port/Std/IfxPort.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxPort_cfg.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxPort_cfg.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/IfxCpu_Intrinsics.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/IfxCpu_Intrinsics.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxPort_reg.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxPort_reg.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxPort_regdef.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxPort_regdef.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Scu/Std/IfxScuWdt.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Scu/Std/IfxScuWdt.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Scu/Std/IfxScuWdt.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Scu/Std/IfxScuWdt.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/IfxCpu_Intrinsics.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/IfxCpu_Intrinsics.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Src/Std/IfxSrc.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Src/Std/IfxSrc.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxSrc_cfg.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxSrc_cfg.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/IfxCpu_Intrinsics.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/IfxCpu_Intrinsics.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxAsclin_PinMap.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxAsclin_PinMap.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Port/Std/IfxPort.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Port/Std/IfxPort.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/_Lib/DataHandling/Ifx_Fifo.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/_Lib/DataHandling/Ifx_Fifo.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/IfxCpu_Intrinsics.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/IfxCpu_Intrinsics.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Service/CpuGeneric/SysSe/Bsp/Bsp.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Service/CpuGeneric/SysSe/Bsp/Bsp.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/IfxCpu_Intrinsics.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/IfxCpu_Intrinsics.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/IfxCpu.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/IfxCpu.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Port/Std/IfxPort.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Port/Std/IfxPort.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Src/Std/IfxSrc.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Src/Std/IfxSrc.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Stm/Std/IfxStm.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Stm/Std/IfxStm.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxStm_cfg.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxStm_cfg.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/IfxCpu_Intrinsics.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/IfxCpu_Intrinsics.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Src/Std/IfxSrc.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Src/Std/IfxSrc.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf_DPipe.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf_DPipe.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Asclin/Asc/IfxAsclin_Asc.o :	c:/Infineon/AURIX-Studio-1.9.16/tools/Compilers/Tasking_1.1r8/ctc/include/string.h
c:/Infineon/AURIX-Studio-1.9.16/tools/Compilers/Tasking_1.1r8/ctc/include/string.h :
