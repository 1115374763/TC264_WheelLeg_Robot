libraries/infineon_libraries/iLLD/TC26B/Tricore/Src/Std/IfxSrc.o :	../libraries/infineon_libraries/iLLD/TC26B/Tricore/Src/Std/IfxSrc.c
../libraries/infineon_libraries/iLLD/TC26B/Tricore/Src/Std/IfxSrc.c :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Src/Std/IfxSrc.o :	../libraries/infineon_libraries/iLLD/TC26B/Tricore/Src/Std/IfxSrc.h
../libraries/infineon_libraries/iLLD/TC26B/Tricore/Src/Std/IfxSrc.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Src/Std/IfxSrc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxSrc_cfg.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxSrc_cfg.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Src/Std/IfxSrc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/IfxCpu_Intrinsics.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/IfxCpu_Intrinsics.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Src/Std/IfxSrc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/Ifx_Types.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/Ifx_Types.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Src/Std/IfxSrc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/Compilers.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/Compilers.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Src/Std/IfxSrc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Configurations/Ifx_Cfg.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Configurations/Ifx_Cfg.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Src/Std/IfxSrc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerTasking.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerTasking.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Src/Std/IfxSrc.o :	c:/Infineon/AURIX-Studio-1.9.16/tools/Compilers/Tasking_1.1r8/ctc/include/stddef.h
c:/Infineon/AURIX-Studio-1.9.16/tools/Compilers/Tasking_1.1r8/ctc/include/stddef.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Src/Std/IfxSrc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/Platform_Types.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/Platform_Types.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Src/Std/IfxSrc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/Ifx_TypesTasking.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/Ifx_TypesTasking.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Src/Std/IfxSrc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/IfxCpu_IntrinsicsTasking.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/iLLD/TC26B/Tricore/Cpu/Std/IfxCpu_IntrinsicsTasking.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Src/Std/IfxSrc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxSrc_reg.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxSrc_reg.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Src/Std/IfxSrc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxSrc_regdef.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxSrc_regdef.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/Src/Std/IfxSrc.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/Ifx_TypesReg.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/Ifx_TypesReg.h :
