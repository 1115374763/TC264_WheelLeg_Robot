libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxScu_cfg.o :	../libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxScu_cfg.c
../libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxScu_cfg.c :
libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxScu_cfg.o :	../libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxScu_cfg.h
../libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxScu_cfg.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxScu_cfg.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Configurations/Ifx_Cfg.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Configurations/Ifx_Cfg.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxScu_cfg.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxScu_bf.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxScu_bf.h :
libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxScu_cfg.o :	c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxFlash_bf.h
c:/Users/daizongqi/AURIX-v1.9.16-workspace/Project_3_20_luntui/libraries/infineon_libraries/Infra/Sfr/TC26B/_Reg/IfxFlash_bf.h :
